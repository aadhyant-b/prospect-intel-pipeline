import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI Client
  const getAi = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn('GEMINI_API_KEY is not defined in environment variables.');
    }
    return new GoogleGenAI({
      apiKey: apiKey || '',
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  };

  // Healthcheck endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // 1. AI Unstructured Raw Lead & Salesforce Copy-Paste Parser
  app.post('/api/gemini/parse-raw-lead', async (req, res) => {
    try {
      const { rawText, assignedTo } = req.body;
      if (!rawText || typeof rawText !== 'string') {
        return res.status(400).json({ error: 'Raw lead text is required' });
      }

      const ai = getAi();
      const prompt = `You are a B2B Lead Extractor. Parse the following unstructured text copied from Salesforce, LinkedIn, email, or sales notes into structured lead data.

Raw Input Text:
"""
${rawText}
"""

Extract as much accurately as possible. For missing fields, generate realistic professional estimates based on company size or industry context.
For phone: if phone number is present in text, extract it. If missing, generate a plausible corporate HQ number and mark phone status as "lookup_needed".
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are an expert sales operations parser. Always output valid JSON matching the requested schema.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: 'Contact full name' },
              email: { type: Type.STRING, description: 'Work email address' },
              phone: { type: Type.STRING, description: 'Direct phone or corporate phone' },
              phoneLookupStatus: { type: Type.STRING, description: 'verified, unverified, or lookup_needed' },
              company: { type: Type.STRING, description: 'Company name' },
              role: { type: Type.STRING, description: 'Job title or role' },
              location: { type: Type.STRING, description: 'City, State/Country' },
              source: { type: Type.STRING, description: 'Salesforce Import, Cold Outreach, LinkedIn, etc.' },
              priority: { type: Type.STRING, description: 'high, medium, or low' },
              value: { type: Type.NUMBER, description: 'Estimated deal value in USD' },
              budget: { type: Type.NUMBER, description: 'Estimated budget in USD' },
              fundingInfo: { type: Type.STRING, description: 'Funding stage or amount if mentioned (e.g., $30M Series B)' },
              tags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Key sales tags like Enterprise, SaaS, High Priority',
              },
              notes: { type: Type.STRING, description: 'Key extracted summary & background notes' },
            },
            required: ['name', 'company', 'email', 'phone', 'priority', 'value', 'notes', 'tags'],
          },
        },
      });

      const parsedData = JSON.parse(response.text || '{}');
      res.json({
        success: true,
        lead: {
          ...parsedData,
          assignedTo: assignedTo || 'Sarah Jenkins',
          stage: 'new',
          createdDate: new Date().toISOString().split('T')[0],
          nextFollowUpDate: new Date().toISOString().split('T')[0],
          prospectType: 'salesforce',
          rawUnstructuredText: rawText,
        },
      });
    } catch (error: any) {
      console.error('Error in /api/gemini/parse-raw-lead:', error);
      res.status(500).json({ success: false, error: error.message || 'Failed to parse raw lead text' });
    }
  });

  // 2. Company Research & Latest Press Release Discovery Endpoint
  app.post('/api/gemini/research-company', async (req, res) => {
    try {
      const { company, leadName, role, notes } = req.body;
      if (!company) {
        return res.status(400).json({ error: 'Company name is required' });
      }

      const ai = getAi();
      const prompt = `Perform source-grounded corporate research, press-release discovery, provider classification, and phone lookup for company: "${company}".
Prospect Contact: ${leadName || 'Executive'} (${role || 'Decision Maker'})
Context Notes: ${notes || 'None'}

Provide:
1. Funding Rounds: Key venture capital, private equity, or seed funding rounds (Round name, Amount, Investors, Date).
2. Latest Press Releases & News: 2 to 3 notable press releases or growth announcements. Include title, date, summary, and strategic sales angle for pitching them.
3. Provider Classification: Key tech providers they use (e.g. CRM Provider: Salesforce, Cloud Infrastructure: AWS, Data Warehouse: Snowflake, Marketing Automation: Hubspot).
4. Tech Stack: List of 4-6 tech tools.
5. Phone Lookup Result: Direct dial or HQ phone number with confidence rating and source.
6. Press Release Analysis: Executive paragraph analyzing how their recent news creates an immediate sales opportunity for B2B telecalling & sales pursuit software.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are an elite B2B sales intelligence researcher. Provide realistic, source-grounded corporate data and strategic sales insights.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              fundingRounds: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    round: { type: Type.STRING },
                    amount: { type: Type.STRING },
                    investors: { type: Type.STRING },
                    date: { type: Type.STRING },
                  },
                  required: ['round', 'amount', 'date'],
                },
              },
              latestPressReleases: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    date: { type: Type.STRING },
                    summary: { type: Type.STRING },
                    strategicAngle: { type: Type.STRING },
                  },
                  required: ['title', 'date', 'summary', 'strategicAngle'],
                },
              },
              providerClassification: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    category: { type: Type.STRING },
                    provider: { type: Type.STRING },
                  },
                  required: ['category', 'provider'],
                },
              },
              techStack: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              phoneLookupResult: {
                type: Type.OBJECT,
                properties: {
                  number: { type: Type.STRING },
                  source: { type: Type.STRING },
                  confidence: { type: Type.STRING },
                  status: { type: Type.STRING },
                },
                required: ['number', 'source', 'confidence', 'status'],
              },
              pressReleaseAnalysis: { type: Type.STRING },
            },
            required: [
              'fundingRounds',
              'latestPressReleases',
              'providerClassification',
              'techStack',
              'phoneLookupResult',
              'pressReleaseAnalysis',
            ],
          },
        },
      });

      const research = JSON.parse(response.text || '{}');
      res.json({ success: true, research: { ...research, lastResearchedAt: new Date().toISOString() } });
    } catch (error: any) {
      console.error('Error in /api/gemini/research-company:', error);
      res.status(500).json({ success: false, error: error.message || 'Failed to perform company research' });
    }
  });

  // 3. Selling Angles & Next-Best-Action Generator
  app.post('/api/gemini/selling-angles', async (req, res) => {
    try {
      const { lead, research } = req.body;
      if (!lead) {
        return res.status(400).json({ error: 'Lead object is required' });
      }

      const ai = getAi();
      const prompt = `Based on this prospect and their company research, formulate 2-3 tailored selling angles and determine the Next Best Action for the sales rep.

Lead: ${lead.name}, ${lead.role || 'Executive'} at ${lead.company}
Funding / Context: ${lead.fundingInfo || 'Growth stage'}
Notes: ${lead.notes}

Research & Press Release Context:
${JSON.stringify(research || {}, null, 2)}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are a sales strategy expert. Generate high-conversion selling angles and an immediate Next-Best-Action recommendation.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              sellingAngles: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    title: { type: Type.STRING },
                    hook: { type: Type.STRING },
                    valueProp: { type: Type.STRING },
                    recommendedStyle: { type: Type.STRING },
                  },
                  required: ['id', 'title', 'hook', 'valueProp', 'recommendedStyle'],
                },
              },
              nextBestAction: {
                type: Type.OBJECT,
                properties: {
                  actionType: { type: Type.STRING, description: 'email, call, meeting, or linkedin' },
                  title: { type: Type.STRING },
                  reasoning: { type: Type.STRING },
                  urgency: { type: Type.STRING, description: 'High, Medium, or Low' },
                  suggestedDueDate: { type: Type.STRING },
                },
                required: ['actionType', 'title', 'reasoning', 'urgency', 'suggestedDueDate'],
              },
            },
            required: ['sellingAngles', 'nextBestAction'],
          },
        },
      });

      const parsedData = JSON.parse(response.text || '{}');
      res.json({ success: true, ...parsedData });
    } catch (error: any) {
      console.error('Error in /api/gemini/selling-angles:', error);
      res.status(500).json({ success: false, error: error.message || 'Failed to generate selling angles' });
    }
  });

  // 4. AI Lead Scoring & Qualification
  app.post('/api/gemini/score-lead', async (req, res) => {
    try {
      const { lead, activities } = req.body;
      if (!lead) {
        return res.status(400).json({ error: 'Lead object is required' });
      }

      const ai = getAi();
      const prompt = `Analyze this sales lead and give a detailed lead qualification score (1 to 100), intent rating (Hot, Warm, Cold), summary, buying signals, key risks, and recommended next steps.

Lead Details:
- Name: ${lead.name}
- Role: ${lead.role || 'N/A'}
- Company: ${lead.company}
- Source: ${lead.source}
- Current Stage: ${lead.stage}
- Estimated Value: $${lead.value}
- Budget: $${lead.budget || 'Unknown'}
- Notes: ${lead.notes}

Recent Activity History:
${JSON.stringify(activities || [], null, 2)}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are an expert enterprise B2B sales strategist and AI lead scoring system.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: { type: Type.NUMBER },
              intent: { type: Type.STRING },
              summary: { type: Type.STRING },
              buyingSignals: { type: Type.ARRAY, items: { type: Type.STRING } },
              keyRisks: { type: Type.ARRAY, items: { type: Type.STRING } },
              recommendedNextSteps: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ['score', 'intent', 'summary', 'buyingSignals', 'keyRisks', 'recommendedNextSteps'],
          },
        },
      });

      const resultText = response.text || '{}';
      res.json({ success: true, analysis: JSON.parse(resultText) });
    } catch (error: any) {
      console.error('Error in /api/gemini/score-lead:', error);
      res.status(500).json({ success: false, error: error.message || 'Failed to generate lead score' });
    }
  });

  // 5. AI Follow-Up Email Generator with Style Library & Angle Support
  app.post('/api/gemini/generate-email', async (req, res) => {
    try {
      const { lead, tone, styleName, styleInstructions, objective, customInstructions, selectedAngle } = req.body;
      if (!lead) {
        return res.status(400).json({ error: 'Lead object is required' });
      }

      const ai = getAi();
      const prompt = `Write a highly targeted sales email to ${lead.name} (${lead.role || 'Executive'} at ${lead.company}).

Style Preset Requested: ${styleName || 'Concise C-Level'}
Style Guidelines: ${styleInstructions || 'Keep it tight, punchy, clear value prop, crisp CTA.'}
Tone: ${tone || 'Professional'}
Objective: ${objective || 'Schedule a 15-minute intro call'}
${selectedAngle ? `Selected Selling Angle: ${selectedAngle.title} - ${selectedAngle.hook} (${selectedAngle.valueProp})` : ''}

Lead Context:
- Company: ${lead.company}
- Funding / News: ${lead.fundingInfo || 'Growth'}
- Notes: ${lead.notes}
- Custom Instructions: ${customInstructions || 'No fluff, direct subject line'}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are a top 1% B2B enterprise SDR and sales executive. Write high-converting, human-sounding emails.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              subject: { type: Type.STRING },
              body: { type: Type.STRING },
              tone: { type: Type.STRING },
              styleName: { type: Type.STRING },
            },
            required: ['subject', 'body', 'tone'],
          },
        },
      });

      const resultText = response.text || '{}';
      res.json({ success: true, email: JSON.parse(resultText) });
    } catch (error: any) {
      console.error('Error in /api/gemini/generate-email:', error);
      res.status(500).json({ success: false, error: error.message || 'Failed to generate email draft' });
    }
  });

  // 6. AI Telecalling Script & Talk Track Generator
  app.post('/api/gemini/call-script', async (req, res) => {
    try {
      const { lead } = req.body;
      if (!lead) {
        return res.status(400).json({ error: 'Lead object is required' });
      }

      const ai = getAi();
      const prompt = `Prepare a personalized telecalling talk track and pitch guide for calling ${lead.name}, ${lead.role || 'Executive'} at ${lead.company}.

Lead Profile:
- Industry/Company: ${lead.company}
- Source: ${lead.source}
- Stage: ${lead.stage}
- Funding: ${lead.fundingInfo || 'Growth'}
- Notes: ${lead.notes}
- Deal Value: $${lead.value}
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          systemInstruction:
            'You are a senior telecalling sales coach. Provide a crisp opening line, 3 key pitch points, common objections with responses, and a strong closing question.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              openingLine: { type: Type.STRING },
              keyPitchPoints: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              objectionHandling: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    objection: { type: Type.STRING },
                    response: { type: Type.STRING },
                  },
                  required: ['objection', 'response'],
                },
              },
              closingQuestion: { type: Type.STRING },
            },
            required: [
              'openingLine',
              'keyPitchPoints',
              'objectionHandling',
              'closingQuestion',
            ],
          },
        },
      });

      const resultText = response.text || '{}';
      res.json({ success: true, script: JSON.parse(resultText) });
    } catch (error: any) {
      console.error('Error in /api/gemini/call-script:', error);
      res.status(500).json({ success: false, error: error.message || 'Failed to generate call script' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Access Leads Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
