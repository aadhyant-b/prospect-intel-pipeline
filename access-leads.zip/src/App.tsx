/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Lead,
  Activity,
  Task,
  TeamMember,
  Role,
  PipelineStage,
  CallOutcome,
  Meeting,
  CadenceRule,
  StylePreset,
  CompanyResearch,
} from './types';
import {
  getStoredLeads,
  saveStoredLeads,
  getStoredActivities,
  saveStoredActivities,
  getStoredTasks,
  saveStoredTasks,
  getStoredTeam,
  saveStoredTeam,
  getStoredMeetings,
  saveStoredMeetings,
  getStoredCadence,
  saveStoredCadence,
  getStoredStyles,
  saveStoredStyles,
} from './utils/storage';

import { Navbar } from './components/Navbar';
import { Sidebar, TabType } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { LeadsView } from './components/LeadsView';
import { KanbanView } from './components/KanbanView';
import { TelecallerQueue } from './components/TelecallerQueue';
import { AnalyticsView } from './components/AnalyticsView';
import { TeamAccessView } from './components/TeamAccessView';
import { SalesforceImportView } from './components/SalesforceImportView';
import { FollowUpsView } from './components/FollowUpsView';
import { CompanyResearchHub } from './components/CompanyResearchHub';
import { StyleLibraryView } from './components/StyleLibraryView';
import { ArchiveView } from './components/ArchiveView';
import { LeadDetailModal } from './components/LeadDetailModal';
import { AddLeadModal } from './components/AddLeadModal';
import { CallLogModal } from './components/CallLogModal';
import { ImportCsvModal } from './components/ImportCsvModal';

export default function App() {
  const [currentRole, setCurrentRole] = useState<Role>('admin');
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');

  // Persisted state
  const [leads, setLeads] = useState<Lead[]>(getStoredLeads);
  const [activities, setActivities] = useState<Activity[]>(getStoredActivities);
  const [tasks, setTasks] = useState<Task[]>(getStoredTasks);
  const [team, setTeam] = useState<TeamMember[]>(getStoredTeam);
  const [meetings, setMeetings] = useState<Meeting[]>(getStoredMeetings);
  const [cadenceRules, setCadenceRules] = useState<CadenceRule[]>(getStoredCadence);
  const [styles, setStyles] = useState<StylePreset[]>(getStoredStyles);

  const [searchQuery, setSearchQuery] = useState('');

  // Modals state
  const [selectedLeadForDetail, setSelectedLeadForDetail] = useState<Lead | null>(null);
  const [selectedLeadForCallLog, setSelectedLeadForCallLog] = useState<Lead | null>(null);
  const [showAddLeadModal, setShowAddLeadModal] = useState(false);
  const [showImportCsvModal, setShowImportCsvModal] = useState(false);

  // Sync back to LocalStorage
  useEffect(() => { saveStoredLeads(leads); }, [leads]);
  useEffect(() => { saveStoredActivities(activities); }, [activities]);
  useEffect(() => { saveStoredTasks(tasks); }, [tasks]);
  useEffect(() => { saveStoredTeam(team); }, [team]);
  useEffect(() => { saveStoredMeetings(meetings); }, [meetings]);
  useEffect(() => { saveStoredCadence(cadenceRules); }, [cadenceRules]);
  useEffect(() => { saveStoredStyles(styles); }, [styles]);

  // Handlers
  const handleUpdateLeadStage = (leadId: string, newStage: PipelineStage) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === leadId ? { ...l, stage: newStage } : l))
    );

    const matchedLead = leads.find((l) => l.id === leadId);
    if (matchedLead) {
      const newAct: Activity = {
        id: `act_${Date.now()}`,
        leadId,
        type: 'stage_change',
        title: `Stage Changed to ${newStage.replace('_', ' ')}`,
        description: `Lead moved to ${newStage.replace('_', ' ')} stage.`,
        performedBy: currentRole === 'admin' ? 'Sarah Jenkins' : 'Telecaller Rep',
        timestamp: new Date().toISOString(),
      };
      setActivities((prev) => [newAct, ...prev]);
    }
  };

  const handleUpdateLeadResearch = (leadId: string, research: CompanyResearch) => {
    setLeads((prev) =>
      prev.map((l) => (l.id === leadId ? { ...l, companyResearch: research } : l))
    );
    if (selectedLeadForDetail && selectedLeadForDetail.id === leadId) {
      setSelectedLeadForDetail((prev) => prev ? { ...prev, companyResearch: research } : null);
    }
  };

  const handleLogCall = (
    leadId: string,
    outcome: CallOutcome,
    notes: string,
    durationSeconds: number,
    nextFollowUpDate?: string
  ) => {
    const todayStr = new Date().toISOString().slice(0, 10);

    setLeads((prev) =>
      prev.map((l) => {
        if (l.id === leadId) {
          return {
            ...l,
            lastContactedDate: todayStr,
            nextFollowUpDate: nextFollowUpDate || l.nextFollowUpDate,
            stage: l.stage === 'new' ? 'contacted' : l.stage,
            notes: notes ? `${notes}\n\n${l.notes || ''}` : l.notes,
          };
        }
        return l;
      })
    );

    const newAct: Activity = {
      id: `act_${Date.now()}`,
      leadId,
      type: 'call',
      title: `Call Logged: ${outcome}`,
      description: notes || `Logged telecall with outcome: ${outcome}`,
      outcome,
      performedBy: 'Priya Sharma',
      timestamp: new Date().toISOString(),
      durationSeconds,
    };
    setActivities((prev) => [newAct, ...prev]);

    setTeam((prev) =>
      prev.map((m) => (m.name === 'Priya Sharma' ? { ...m, callsToday: m.callsToday + 1 } : m))
    );
  };

  const handleAddLead = (leadInput: any) => {
    const newLead: Lead = {
      id: leadInput.id || `lead_${Date.now()}`,
      createdDate: leadInput.createdDate || new Date().toISOString().slice(0, 10),
      aiScore: leadInput.aiScore || 80,
      aiIntent: leadInput.aiIntent || 'Hot',
      ...leadInput,
    };
    setLeads((prev) => [newLead, ...prev]);
  };

  const handleDeleteLeads = (leadIdsToDelete: string[]) => {
    setLeads((prev) => prev.filter((l) => !leadIdsToDelete.includes(l.id)));
  };

  const handleBatchScoreLeads = async (leadIds: string[]) => {
    setLeads((prev) =>
      prev.map((l) =>
        leadIds.includes(l.id)
          ? {
              ...l,
              aiScore: Math.floor(Math.random() * 25) + 75,
              aiIntent: 'Hot',
            }
          : l
      )
    );
  };

  const handleImportLeads = (importedList: Partial<Lead>[]) => {
    const fullLeads: Lead[] = importedList.map((imp, idx) => ({
      id: imp.id || `lead_imp_${Date.now()}_${idx}`,
      name: imp.name || 'Imported Lead',
      email: imp.email || 'imported@lead.com',
      phone: imp.phone || '+1 (555) 000-0000',
      company: imp.company || 'Company',
      role: imp.role,
      location: imp.location,
      source: imp.source || 'Website',
      stage: imp.stage || 'new',
      priority: imp.priority || 'medium',
      value: imp.value || 10000,
      budget: imp.budget || 12000,
      assignedTo: imp.assignedTo || 'Priya Sharma',
      tags: imp.tags || ['Imported CSV'],
      notes: imp.notes || '',
      createdDate: imp.createdDate || new Date().toISOString().slice(0, 10),
      aiScore: 75,
      aiIntent: 'Warm',
    }));

    setLeads((prev) => [...fullLeads, ...prev]);
  };

  const handleAddTask = (taskData: Omit<Task, 'id'>) => {
    const newTask: Task = {
      ...taskData,
      id: `task_${Date.now()}`,
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const handleSnoozeTask = (taskId: string, days: number) => {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + days);
    const futureStr = futureDate.toISOString().slice(0, 10);

    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, dueDate: futureStr } : t))
    );
  };

  const handleCompleteTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: true } : t))
    );
  };

  const handleAdvanceCadence = (leadId: string) => {
    setLeads((prev) =>
      prev.map((l) =>
        l.id === leadId ? { ...l, cadenceStep: Math.min((l.cadenceStep || 1) + 1, 5) } : l
      )
    );
  };

  const handleRestoreLead = (leadId: string) => {
    setLeads((prev) =>
      prev.map((l) =>
        l.id === leadId ? { ...l, stage: 'qualifying', isArchived: false } : l
      )
    );
  };

  const handleAddStyle = (newStyle: StylePreset) => {
    setStyles((prev) => [...prev, newStyle]);
  };

  const handleUpdateRole = (memberId: string, newRole: Role) => {
    setTeam((prev) =>
      prev.map((m) => (m.id === memberId ? { ...m, role: newRole } : m))
    );
  };

  const handleAddTeamMember = (memberData: Omit<TeamMember, 'id'>) => {
    const newMember: TeamMember = {
      ...memberData,
      id: `user_${Date.now()}`,
    };
    setTeam((prev) => [...prev, newMember]);
  };

  const pendingCallbacksCount = leads.filter(
    (l) => l.nextFollowUpDate && l.nextFollowUpDate === new Date().toISOString().slice(0, 10)
  ).length;

  const dueTasksCount = tasks.filter(
    (t) => !t.completed && t.dueDate <= new Date().toISOString().slice(0, 10)
  ).length;

  const todayCallsCount = activities.filter(
    (a) => a.type === 'call' && a.timestamp.slice(0, 10) === new Date().toISOString().slice(0, 10)
  ).length;

  return (
    <div className="min-h-screen bg-[#09090b] text-[#fafafa] flex flex-col font-sans antialiased selection:bg-emerald-500 selection:text-black">
      {/* Top Header Navbar */}
      <Navbar
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenAddModal={() => setActiveTab('salesforce_import')}
        onOpenImportModal={() => setShowImportCsvModal(true)}
        totalLeadsCount={leads.length}
        todayCallsCount={todayCallsCount}
      />

      {/* Main Body */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Left Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          role={currentRole}
          pendingCallbacksCount={pendingCallbacksCount}
          dueTasksCount={dueTasksCount}
        />

        {/* View Canvas */}
        <main className="flex-1 overflow-y-auto bg-[#09090b] p-4 md:p-6">
          {activeTab === 'dashboard' && (
            <DashboardView
              leads={leads}
              activities={activities}
              tasks={tasks}
              onSelectLead={(l) => setSelectedLeadForDetail(l)}
              onNavigateToTab={(tab) => setActiveTab(tab as TabType)}
            />
          )}

          {activeTab === 'salesforce_import' && (
            <SalesforceImportView
              onAddLead={handleAddLead}
              onOpenLeadDetail={(l) => setSelectedLeadForDetail(l)}
            />
          )}

          {activeTab === 'followups' && (
            <FollowUpsView
              leads={leads}
              tasks={tasks}
              meetings={meetings}
              cadenceRules={cadenceRules}
              onOpenLeadDetail={(l) => setSelectedLeadForDetail(l)}
              onLogCall={(l) => setSelectedLeadForCallLog(l)}
              onAdvanceCadence={handleAdvanceCadence}
              onSnoozeTask={handleSnoozeTask}
              onCompleteTask={handleCompleteTask}
            />
          )}

          {activeTab === 'research_hub' && (
            <CompanyResearchHub
              leads={leads}
              onUpdateLeadResearch={handleUpdateLeadResearch}
              onOpenLeadDetail={(l) => setSelectedLeadForDetail(l)}
            />
          )}

          {activeTab === 'leads' && (
            <LeadsView
              leads={leads}
              role={currentRole}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onSelectLead={(l) => setSelectedLeadForDetail(l)}
              onOpenAddModal={() => setActiveTab('salesforce_import')}
              onOpenImportModal={() => setShowImportCsvModal(true)}
              onOpenCallLogModal={(l) => setSelectedLeadForCallLog(l)}
              onUpdateLeadStage={handleUpdateLeadStage}
              onDeleteLeads={handleDeleteLeads}
              onBatchScoreLeads={handleBatchScoreLeads}
            />
          )}

          {activeTab === 'kanban' && (
            <KanbanView
              leads={leads}
              onSelectLead={(l) => setSelectedLeadForDetail(l)}
              onUpdateLeadStage={handleUpdateLeadStage}
              onOpenAddModal={() => setActiveTab('salesforce_import')}
              onOpenCallLogModal={(l) => setSelectedLeadForCallLog(l)}
            />
          )}

          {activeTab === 'telecaller' && (
            <TelecallerQueue
              leads={leads}
              activities={activities}
              onLogCall={handleLogCall}
              onSelectLead={(l) => setSelectedLeadForDetail(l)}
            />
          )}

          {activeTab === 'style_library' && (
            <StyleLibraryView
              styles={styles}
              leads={leads}
              onAddStyle={handleAddStyle}
              onOpenLeadDetail={(l) => setSelectedLeadForDetail(l)}
            />
          )}

          {activeTab === 'archive' && (
            <ArchiveView
              leads={leads}
              onOpenLeadDetail={(l) => setSelectedLeadForDetail(l)}
              onRestoreLead={handleRestoreLead}
            />
          )}

          {activeTab === 'analytics' && (
            <AnalyticsView leads={leads} activities={activities} team={team} />
          )}

          {activeTab === 'team' && (
            <TeamAccessView
              team={team}
              onUpdateRole={handleUpdateRole}
              onAddTeamMember={handleAddTeamMember}
            />
          )}
        </main>
      </div>

      {/* Modals & Drawers */}
      {selectedLeadForDetail && (
        <LeadDetailModal
          lead={selectedLeadForDetail}
          activities={activities}
          tasks={tasks}
          styles={styles}
          onClose={() => setSelectedLeadForDetail(null)}
          onUpdateLeadStage={handleUpdateLeadStage}
          onOpenCallLogModal={(l) => setSelectedLeadForCallLog(l)}
          onAddTask={handleAddTask}
          onUpdateLeadResearch={handleUpdateLeadResearch}
        />
      )}

      {selectedLeadForCallLog && (
        <CallLogModal
          lead={selectedLeadForCallLog}
          onClose={() => setSelectedLeadForCallLog(null)}
          onLogCall={handleLogCall}
        />
      )}

      {showAddLeadModal && (
        <AddLeadModal
          onClose={() => setShowAddLeadModal(false)}
          onAddLead={handleAddLead}
        />
      )}

      {showImportCsvModal && (
        <ImportCsvModal
          onClose={() => setShowImportCsvModal(false)}
          onImportLeads={handleImportLeads}
        />
      )}
    </div>
  );
}
