export type Role = 'admin' | 'manager' | 'telecaller';

export type PipelineStage = 
  | 'new'
  | 'contacted'
  | 'qualifying'
  | 'proposal_sent'
  | 'negotiation'
  | 'won'
  | 'lost';

export type LeadPriority = 'high' | 'medium' | 'low';

export type LeadSource = 
  | 'Website' 
  | 'Inbound Call' 
  | 'LinkedIn' 
  | 'Salesforce Import'
  | 'Google Ads' 
  | 'Referral' 
  | 'Cold Calling' 
  | 'Event';

export interface FundingRound {
  round: string; // e.g., 'Series B'
  amount: string; // e.g., '$45M'
  investors?: string; // e.g., 'Sequoia Capital, Accel'
  date: string; // e.g., 'June 2026'
}

export interface PressRelease {
  title: string;
  date: string;
  summary: string;
  strategicAngle: string;
  url?: string;
}

export interface ProviderCategory {
  category: string; // e.g., 'CRM', 'Cloud Infra', 'Marketing Automation'
  provider: string; // e.g., 'Salesforce', 'AWS', 'Hubspot'
}

export interface PhoneLookupResult {
  number: string;
  source: string;
  confidence: string; // e.g., 'High (Verified)', 'Medium (Corporate HQ)'
  status: 'verified' | 'unverified' | 'lookup_needed';
}

export interface CompanyResearch {
  fundingRounds: FundingRound[];
  latestPressReleases: PressRelease[];
  providerClassification: ProviderCategory[];
  techStack: string[];
  phoneLookupResult?: PhoneLookupResult;
  pressReleaseAnalysis: string;
  lastResearchedAt?: string;
}

export interface SellingAngle {
  id: string;
  title: string;
  hook: string;
  valueProp: string;
  recommendedStyle: string;
}

export interface NextBestAction {
  actionType: 'email' | 'call' | 'meeting' | 'linkedin';
  title: string;
  reasoning: string;
  urgency: 'High' | 'Medium' | 'Low';
  suggestedDueDate: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  role?: string;
  location?: string;
  source: LeadSource;
  stage: PipelineStage;
  priority: LeadPriority;
  value: number; // Estimated deal value
  budget?: number;
  assignedTo: string; // User ID or Name
  tags: string[];
  notes: string;
  createdDate: string;
  lastContactedDate?: string;
  nextFollowUpDate?: string;
  aiScore?: number; // 1-100
  aiIntent?: 'Hot' | 'Warm' | 'Cold';
  aiSummary?: string;
  
  // Enterprise Pursuit Enhancements
  fundingInfo?: string;
  prospectType?: 'salesforce' | 'self_prospected' | 'inbound';
  salesforceRawId?: string;
  rawUnstructuredText?: string;
  phoneLookupStatus?: 'verified' | 'unverified' | 'lookup_needed';
  cadenceStep?: number; // 1-5
  cadenceName?: string;
  companyResearch?: CompanyResearch;
  sellingAngles?: SellingAngle[];
  nextBestAction?: NextBestAction;
  isArchived?: boolean;
  isMeetingScheduled?: boolean;
  meetingDate?: string;
  meetingTime?: string;
}

export type CallOutcome = 
  | 'Connected - Interested'
  | 'Connected - Callback Requested'
  | 'Connected - Not Interested'
  | 'Left Voicemail'
  | 'No Answer / Busy'
  | 'Wrong Number';

export interface Activity {
  id: string;
  leadId: string;
  type: 'call' | 'email' | 'meeting' | 'note' | 'stage_change' | 'research';
  title: string;
  description: string;
  outcome?: CallOutcome;
  performedBy: string;
  timestamp: string;
  durationSeconds?: number;
}

export interface Task {
  id: string;
  leadId: string;
  title: string;
  dueDate: string;
  dueTime?: string;
  assignedTo: string;
  completed: boolean;
  type: 'call' | 'email' | 'meeting' | 'followup';
}

export interface Meeting {
  id: string;
  leadId: string;
  leadName: string;
  company: string;
  title: string;
  date: string;
  time: string;
  participants: string[];
  notes: string;
  status: 'scheduled' | 'completed' | 'cancelled';
}

export interface CadenceRule {
  stepNumber: number;
  dayOffset: number;
  channel: 'email' | 'call' | 'linkedin' | 'followup';
  title: string;
  description: string;
  recommendedStyle: string;
}

export interface StylePreset {
  id: string;
  name: string;
  description: string;
  tone: string;
  promptInstructions: string;
}

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatar: string;
  assignedLeadsCount: number;
  callsToday: number;
  dealsClosed: number;
  revenueClosed: number;
  conversionRate: number;
}

export interface AIAnalysisResult {
  score: number; // 1-100
  intent: 'Hot' | 'Warm' | 'Cold';
  summary: string;
  buyingSignals: string[];
  keyRisks: string[];
  recommendedNextSteps: string[];
}

export interface AIEmailDraft {
  subject: string;
  body: string;
  tone: string;
  styleName?: string;
}

export interface AICallScript {
  openingLine: string;
  keyPitchPoints: string[];
  objectionHandling: { objection: string; response: string }[];
  closingQuestion: string;
}
