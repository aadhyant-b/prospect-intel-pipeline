import { Lead, LeadPriority, LeadSource, PipelineStage } from '../types';

export function exportLeadsToCSV(leads: Lead[]) {
  const headers = [
    'ID',
    'Name',
    'Email',
    'Phone',
    'Company',
    'Role',
    'Location',
    'Source',
    'Stage',
    'Priority',
    'Estimated Value ($)',
    'Budget ($)',
    'Assigned To',
    'Tags',
    'AI Score',
    'AI Intent',
    'Created Date',
    'Last Contacted',
    'Notes',
  ];

  const rows = leads.map((lead) => [
    lead.id,
    `"${lead.name.replace(/"/g, '""')}"`,
    `"${lead.email.replace(/"/g, '""')}"`,
    `"${lead.phone.replace(/"/g, '""')}"`,
    `"${lead.company.replace(/"/g, '""')}"`,
    `"${(lead.role || '').replace(/"/g, '""')}"`,
    `"${(lead.location || '').replace(/"/g, '""')}"`,
    lead.source,
    lead.stage,
    lead.priority,
    lead.value || 0,
    lead.budget || 0,
    `"${lead.assignedTo.replace(/"/g, '""')}"`,
    `"${lead.tags.join(', ')}"`,
    lead.aiScore || '',
    lead.aiIntent || '',
    lead.createdDate,
    lead.lastContactedDate || '',
    `"${(lead.notes || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `AccessLeads_Export_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function generateSampleCSVTemplate() {
  const sampleCsv = `Name,Email,Phone,Company,Role,Location,Source,Stage,Priority,Value,Budget,AssignedTo,Tags,Notes
Sarah Connor,sconnor@cyberdyne.org,+1 (555) 999-0011,Cyberdyne Systems,Head of Security,Los Angeles CA,Website,new,high,50000,60000,Priya Sharma,"Security, Enterprise",Interested in cloud lead security compliance
Arthur Dent,adent@hitchhiker.space,+1 (555) 424-2424,Magrathea Planet Builders,Procurement Lead,London UK,LinkedIn,contacted,medium,25000,30000,David Miller,"Consulting, SaaS",Inquired about telecaller CRM integration`;

  const blob = new Blob([sampleCsv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'AccessLeads_Sample_Import_Template.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function parseCSVText(csvText: string): Partial<Lead>[] {
  const lines = csvText.split(/\r\n|\n/).filter((line) => line.trim() !== '');
  if (lines.length < 2) return [];

  // simple CSV parser handling quotes
  const parseLine = (line: string): string[] => {
    const result: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(cur.trim());
        cur = '';
      } else {
        cur += char;
      }
    }
    result.push(cur.trim());
    return result;
  };

  const headers = parseLine(lines[0]).map((h) => h.toLowerCase().replace(/[^a-z]/g, ''));

  const leads: Partial<Lead>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseLine(lines[i]);
    if (values.length < 2) continue;

    const lead: Partial<Lead> = {
      id: `lead_imp_${Date.now()}_${i}`,
      createdDate: new Date().toISOString().slice(0, 10),
      stage: 'new' as PipelineStage,
      priority: 'medium' as LeadPriority,
      source: 'Website' as LeadSource,
      value: 10000,
      tags: ['Imported'],
      notes: '',
    };

    headers.forEach((header, idx) => {
      const val = values[idx] || '';
      if (!val) return;

      if (header.includes('name')) lead.name = val;
      else if (header.includes('email')) lead.email = val;
      else if (header.includes('phone')) lead.phone = val;
      else if (header.includes('company')) lead.company = val;
      else if (header.includes('role')) lead.role = val;
      else if (header.includes('location')) lead.location = val;
      else if (header.includes('source')) lead.source = val as LeadSource;
      else if (header.includes('stage')) lead.stage = val.toLowerCase() as PipelineStage;
      else if (header.includes('priority')) lead.priority = val.toLowerCase() as LeadPriority;
      else if (header.includes('value')) lead.value = Number(val.replace(/[^0-9.]/g, '')) || 10000;
      else if (header.includes('budget')) lead.budget = Number(val.replace(/[^0-9.]/g, '')) || 0;
      else if (header.includes('assigned')) lead.assignedTo = val;
      else if (header.includes('tag')) lead.tags = val.split(',').map((t) => t.trim());
      else if (header.includes('note')) lead.notes = val;
    });

    if (lead.name || lead.email || lead.company) {
      if (!lead.name) lead.name = lead.email || 'Unnamed Lead';
      if (!lead.company) lead.company = 'Independent / Unknown';
      if (!lead.phone) lead.phone = '+1 (555) 000-0000';
      if (!lead.assignedTo) lead.assignedTo = 'Unassigned';
      leads.push(lead);
    }
  }

  return leads;
}
