import { Lead, Activity, Task, TeamMember, StylePreset, Meeting, CadenceRule } from '../types';
import {
  INITIAL_LEADS,
  INITIAL_ACTIVITIES,
  INITIAL_TASKS,
  INITIAL_TEAM,
  INITIAL_STYLE_PRESETS,
  INITIAL_MEETINGS,
  DEFAULT_CADENCE,
} from '../data/mockData';

const KEYS = {
  LEADS: 'accessleads_pursuit_leads_v2',
  ACTIVITIES: 'accessleads_pursuit_activities_v2',
  TASKS: 'accessleads_pursuit_tasks_v2',
  TEAM: 'accessleads_pursuit_team_v2',
  STYLES: 'accessleads_pursuit_styles_v2',
  MEETINGS: 'accessleads_pursuit_meetings_v2',
  CADENCE: 'accessleads_pursuit_cadence_v2',
};

export const loadFromStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      return JSON.parse(raw) as T;
    }
  } catch (err) {
    console.error(`Failed to load key ${key} from localStorage`, err);
  }
  return defaultValue;
};

export const saveToStorage = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Failed to save key ${key} to localStorage`, err);
  }
};

export const getStoredLeads = (): Lead[] => loadFromStorage(KEYS.LEADS, INITIAL_LEADS);
export const saveStoredLeads = (leads: Lead[]) => saveToStorage(KEYS.LEADS, leads);

export const getStoredActivities = (): Activity[] => loadFromStorage(KEYS.ACTIVITIES, INITIAL_ACTIVITIES);
export const saveStoredActivities = (activities: Activity[]) => saveToStorage(KEYS.ACTIVITIES, activities);

export const getStoredTasks = (): Task[] => loadFromStorage(KEYS.TASKS, INITIAL_TASKS);
export const saveStoredTasks = (tasks: Task[]) => saveToStorage(KEYS.TASKS, tasks);

export const getStoredTeam = (): TeamMember[] => loadFromStorage(KEYS.TEAM, INITIAL_TEAM);
export const saveStoredTeam = (team: TeamMember[]) => saveToStorage(KEYS.TEAM, team);

export const getStoredStyles = (): StylePreset[] => loadFromStorage(KEYS.STYLES, INITIAL_STYLE_PRESETS);
export const saveStoredStyles = (styles: StylePreset[]) => saveToStorage(KEYS.STYLES, styles);

export const getStoredMeetings = (): Meeting[] => loadFromStorage(KEYS.MEETINGS, INITIAL_MEETINGS);
export const saveStoredMeetings = (meetings: Meeting[]) => saveToStorage(KEYS.MEETINGS, meetings);

export const getStoredCadence = (): CadenceRule[] => loadFromStorage(KEYS.CADENCE, DEFAULT_CADENCE);
export const saveStoredCadence = (cadence: CadenceRule[]) => saveToStorage(KEYS.CADENCE, cadence);

export const resetStorageToDefaults = () => {
  localStorage.removeItem(KEYS.LEADS);
  localStorage.removeItem(KEYS.ACTIVITIES);
  localStorage.removeItem(KEYS.TASKS);
  localStorage.removeItem(KEYS.TEAM);
  localStorage.removeItem(KEYS.STYLES);
  localStorage.removeItem(KEYS.MEETINGS);
  localStorage.removeItem(KEYS.CADENCE);
};
