import React from 'react';
import {
  Users,
  Plus,
  FileSpreadsheet,
  Search,
  Sparkles,
  PhoneCall,
  UserCheck,
  Shield,
  Briefcase,
} from 'lucide-react';
import { Role } from '../types';

interface NavbarProps {
  currentRole: Role;
  onRoleChange: (role: Role) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenAddModal: () => void;
  onOpenImportModal: () => void;
  totalLeadsCount: number;
  todayCallsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  onRoleChange,
  searchQuery,
  onSearchChange,
  onOpenAddModal,
  onOpenImportModal,
  totalLeadsCount,
  todayCallsCount,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#09090b] border-b border-[#27272a] text-zinc-100 px-4 py-3 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 max-w-7xl mx-auto">
        {/* Brand & Stats */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-emerald-500 text-black font-extrabold text-sm shadow">
            AL
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-base tracking-tight text-white">
                Access Leads
              </span>
              <span className="px-2 py-0.5 text-[11px] font-medium bg-emerald-500/10 text-emerald-400 rounded-full border border-emerald-500/20 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" /> CRM v2.4
              </span>
            </div>
            <p className="text-[11px] text-zinc-400">
              Lead Management & Telecalling Operations
            </p>
          </div>
        </div>

        {/* Global Search */}
        <div className="relative flex-1 max-w-md mx-2">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Search leads, companies, emails, or phone..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full bg-[#18181b] text-zinc-100 placeholder-zinc-500 pl-9 pr-4 py-2 rounded-lg text-xs border border-[#27272a] focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 transition"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-2.5 text-xs text-zinc-400 hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Controls, Role Switcher & Primary Actions */}
        <div className="flex items-center flex-wrap gap-2 justify-end">
          {/* Quick Metrics */}
          <div className="hidden lg:flex items-center space-x-3 text-xs bg-[#18181b] px-3 py-1.5 rounded-lg border border-[#27272a]">
            <span className="text-zinc-400">
              Leads:{' '}
              <strong className="text-zinc-200">{totalLeadsCount}</strong>
            </span>
            <span className="text-zinc-600">•</span>
            <span className="text-zinc-400 flex items-center gap-1">
              <PhoneCall className="w-3 h-3 text-emerald-400" />
              Today's Calls:{' '}
              <strong className="text-emerald-400">{todayCallsCount}</strong>
            </span>
          </div>

          {/* Role Switcher */}
          <div className="flex items-center bg-[#18181b] p-1 rounded-lg border border-[#27272a]">
            <button
              onClick={() => onRoleChange('admin')}
              className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition font-medium ${
                currentRole === 'admin'
                  ? 'bg-[#27272a] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="Full Admin Privileges"
            >
              <Shield className="w-3 h-3" /> Admin
            </button>
            <button
              onClick={() => onRoleChange('manager')}
              className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition font-medium ${
                currentRole === 'manager'
                  ? 'bg-[#27272a] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="Manager - Pipeline & Team View"
            >
              <Briefcase className="w-3 h-3" /> Manager
            </button>
            <button
              onClick={() => onRoleChange('telecaller')}
              className={`flex items-center gap-1 text-xs px-2.5 py-1 rounded-md transition font-medium ${
                currentRole === 'telecaller'
                  ? 'bg-[#27272a] text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="Telecaller - Fast Dial Mode"
            >
              <UserCheck className="w-3 h-3" /> Telecaller
            </button>
          </div>

          {/* CSV Import */}
          <button
            onClick={onOpenImportModal}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-zinc-200 bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] rounded-lg transition"
            title="Import Leads from CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Import CSV</span>
          </button>

          {/* Add Lead */}
          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-black bg-white hover:bg-zinc-200 rounded-lg shadow-sm transition transform active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add Lead</span>
          </button>
        </div>
      </div>
    </header>
  );
};
