import React from 'react';
import { Archive, Trophy, XCircle, RotateCcw, Building2, Calendar, DollarSign, UserCheck } from 'lucide-react';
import { Lead } from '../types';

interface ArchiveViewProps {
  leads: Lead[];
  onOpenLeadDetail: (lead: Lead) => void;
  onRestoreLead: (leadId: string) => void;
}

export const ArchiveView: React.FC<ArchiveViewProps> = ({
  leads,
  onOpenLeadDetail,
  onRestoreLead,
}) => {
  const wonLeads = leads.filter((l) => l.stage === 'won' || l.isArchived);
  const lostLeads = leads.filter((l) => l.stage === 'lost');

  const totalWonValue = wonLeads.reduce((acc, l) => acc + (l.value || 0), 0);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Archive className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-zinc-100">
              Meetings & Closed Pursuit Archive
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Historical repository of closed deals, won contracts, lost opportunities, and archived pursuits.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs bg-[#09090b] px-4 py-2 rounded-xl border border-[#27272a]">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span className="text-zinc-400">Total Closed Won Revenue:</span>
          <strong className="text-emerald-400 text-sm font-bold">
            ${totalWonValue.toLocaleString()}
          </strong>
        </div>
      </div>

      {/* Won Deals Grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5 px-1">
          <Trophy className="w-4 h-4 text-emerald-400" /> Closed Won Contracts ({wonLeads.length})
        </h3>

        {wonLeads.length === 0 ? (
          <div className="bg-[#18181b] border border-[#27272a] p-6 rounded-2xl text-center text-xs text-zinc-500">
            No closed won deals recorded yet.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {wonLeads.map((lead) => (
              <div
                key={lead.id}
                className="bg-[#18181b] border border-[#27272a] hover:border-emerald-500/40 p-4 rounded-xl space-y-3 text-xs transition"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-100 text-sm">{lead.company}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                    Won (${(lead.value || 0).toLocaleString()})
                  </span>
                </div>

                <div className="text-zinc-400 space-y-1">
                  <div>
                    Contact: <strong className="text-zinc-200">{lead.name}</strong> ({lead.role || 'Executive'})
                  </div>
                  <div className="text-zinc-500 text-[11px]">Source: {lead.source}</div>
                </div>

                <div className="p-2 bg-[#09090b] rounded-lg border border-[#27272a] text-zinc-400 text-[11px]">
                  {lead.notes || 'Contract successfully closed.'}
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    onClick={() => onOpenLeadDetail(lead)}
                    className="text-emerald-400 hover:underline font-semibold"
                  >
                    View Pursuit File →
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lost Deals Grid */}
      <div className="space-y-3 pt-4 border-t border-[#27272a]">
        <h3 className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5 px-1">
          <XCircle className="w-4 h-4 text-rose-400" /> Closed Lost & Unqualified Opportunities ({lostLeads.length})
        </h3>

        {lostLeads.length === 0 ? (
          <div className="bg-[#18181b] border border-[#27272a] p-6 rounded-2xl text-center text-xs text-zinc-500">
            No closed lost deals recorded.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {lostLeads.map((lead) => (
              <div
                key={lead.id}
                className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl space-y-3 text-xs opacity-75 hover:opacity-100 transition"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-200">{lead.company}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30">
                    Lost (${(lead.value || 0).toLocaleString()})
                  </span>
                </div>

                <div className="text-zinc-400">
                  Contact: <strong className="text-zinc-200">{lead.name}</strong>
                </div>

                <div className="p-2 bg-[#09090b] rounded-lg border border-[#27272a] text-zinc-400 text-[11px]">
                  {lead.notes || 'Deal closed lost.'}
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={() => onRestoreLead(lead.id)}
                    className="text-zinc-400 hover:text-white flex items-center gap-1 text-[11px] font-semibold"
                  >
                    <RotateCcw className="w-3 h-3 text-emerald-400" /> Re-open Pursuit
                  </button>

                  <button
                    onClick={() => onOpenLeadDetail(lead)}
                    className="text-emerald-400 hover:underline font-semibold text-[11px]"
                  >
                    View File →
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
