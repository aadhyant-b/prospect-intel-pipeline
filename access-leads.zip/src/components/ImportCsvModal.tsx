import React, { useState } from 'react';
import { X, FileSpreadsheet, Upload, Download, CheckCircle, AlertCircle } from 'lucide-react';
import { Lead } from '../types';
import { parseCSVText, generateSampleCSVTemplate } from '../utils/csvUtils';

interface ImportCsvModalProps {
  onClose: () => void;
  onImportLeads: (leads: Partial<Lead>[]) => void;
}

export const ImportCsvModal: React.FC<ImportCsvModalProps> = ({ onClose, onImportLeads }) => {
  const [csvText, setCsvText] = useState('');
  const [parsedLeads, setParsedLeads] = useState<Partial<Lead>[]>([]);
  const [errorMsg, setErrorMsg] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setCsvText(content);
      try {
        const results = parseCSVText(content);
        setParsedLeads(results);
        setErrorMsg('');
      } catch (err: any) {
        setErrorMsg('Failed to parse CSV file format.');
      }
    };
    reader.readAsText(file);
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setCsvText(val);
    try {
      const results = parseCSVText(val);
      setParsedLeads(results);
      setErrorMsg('');
    } catch (err: any) {
      setErrorMsg('Failed to parse CSV text.');
    }
  };

  const handleConfirmImport = () => {
    if (parsedLeads.length === 0) return;
    onImportLeads(parsedLeads);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#18181b] border border-[#27272a] w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden text-zinc-100 my-auto">
        <div className="bg-[#09090b] p-4 border-b border-[#27272a] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-bold text-zinc-100">Batch Import Leads from CSV</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          {/* Top Info & Download Template */}
          <div className="flex items-center justify-between bg-[#09090b] p-3 rounded-xl border border-[#27272a]">
            <p className="text-zinc-300">Need the standard import format?</p>
            <button
              onClick={generateSampleCSVTemplate}
              className="flex items-center gap-1 px-3 py-1.5 bg-[#18181b] hover:bg-zinc-800 text-zinc-200 border border-[#27272a] font-semibold rounded-lg transition"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" /> Download Sample Template
            </button>
          </div>

          {/* Drag & Drop File Upload */}
          <div className="border-2 border-dashed border-[#27272a] hover:border-emerald-500 bg-[#09090b] rounded-xl p-6 text-center space-y-2 cursor-pointer relative transition">
            <input
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <Upload className="w-8 h-8 text-emerald-400 mx-auto" />
            <div className="font-semibold text-zinc-200">
              Click or drag a .csv file here to upload
            </div>
            <p className="text-[11px] text-zinc-400">Supports Name, Email, Phone, Company, Stage, Value, Notes</p>
          </div>

          {/* Paste Raw CSV Area */}
          <div className="space-y-1">
            <label className="text-zinc-300 font-semibold block">Or paste raw CSV text:</label>
            <textarea
              rows={4}
              placeholder="Name,Email,Phone,Company,Role,Source,Value,Notes..."
              value={csvText}
              onChange={handleTextChange}
              className="w-full bg-[#09090b] text-zinc-100 font-mono text-[11px] border border-[#27272a] rounded-xl p-3 focus:outline-none"
            />
          </div>

          {/* Preview count */}
          {parsedLeads.length > 0 && (
            <div className="p-3 bg-emerald-950/20 border border-emerald-500/30 rounded-xl flex items-center justify-between text-emerald-300 font-semibold">
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-400" /> Ready to import {parsedLeads.length} leads
              </span>
              <span className="text-[11px] text-emerald-400/80">Columns auto-mapped</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-rose-950/20 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-300 font-semibold">
              <AlertCircle className="w-4 h-4 text-rose-400" /> {errorMsg}
            </div>
          )}

          <div className="flex justify-end space-x-2 pt-2 border-t border-[#27272a]">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#09090b] hover:bg-zinc-800 text-zinc-300 border border-[#27272a] rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirmImport}
              disabled={parsedLeads.length === 0}
              className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 text-black font-semibold rounded-lg shadow-sm"
            >
              Confirm & Import {parsedLeads.length} Leads
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
