import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Phone,
  Mail,
  MoreVertical,
  Plus,
  FileSpreadsheet,
  CheckSquare,
  Square,
  Sparkles,
  Flame,
  UserCheck,
  Building,
  DollarSign,
  Tag,
  Trash2,
} from 'lucide-react';
import { Lead, LeadPriority, LeadSource, PipelineStage, Role } from '../types';
import { exportLeadsToCSV } from '../utils/csvUtils';

interface LeadsViewProps {
  leads: Lead[];
  role: Role;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSelectLead: (lead: Lead) => void;
  onOpenAddModal: () => void;
  onOpenImportModal: () => void;
  onOpenCallLogModal: (lead: Lead) => void;
  onUpdateLeadStage: (leadId: string, newStage: PipelineStage) => void;
  onDeleteLeads: (leadIds: string[]) => void;
  onBatchScoreLeads: (leadIds: string[]) => void;
}

const STAGE_LABELS: Record<PipelineStage, string> = {
  new: 'New',
  contacted: 'Contacted',
  qualifying: 'Qualifying',
  proposal_sent: 'Proposal Sent',
  negotiation: 'Negotiation',
  won: 'Won',
  lost: 'Lost',
};

const STAGE_BADGES: Record<PipelineStage, string> = {
  new: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  contacted: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
  qualifying: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  proposal_sent: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
  negotiation: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
  won: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  lost: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
};

export const LeadsView: React.FC<LeadsViewProps> = ({
  leads,
  role,
  searchQuery,
  onSearchChange,
  onSelectLead,
  onOpenAddModal,
  onOpenImportModal,
  onOpenCallLogModal,
  onUpdateLeadStage,
  onDeleteLeads,
  onBatchScoreLeads,
}) => {
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'value' | 'createdDate' | 'score' | 'name'>('createdDate');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [selectedLeadIds, setSelectedLeadIds] = useState<string[]>([]);

  // Filter & Sort Logic
  const filteredLeads = useMemo(() => {
    return leads
      .filter((l) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = l.name.toLowerCase().includes(q);
          const matchCompany = l.company.toLowerCase().includes(q);
          const matchEmail = l.email.toLowerCase().includes(q);
          const matchPhone = l.phone.includes(q);
          const matchNotes = l.notes.toLowerCase().includes(q);
          if (!matchName && !matchCompany && !matchEmail && !matchPhone && !matchNotes) {
            return false;
          }
        }
        // Stage filter
        if (stageFilter !== 'all' && l.stage !== stageFilter) return false;
        // Source filter
        if (sourceFilter !== 'all' && l.source !== sourceFilter) return false;
        // Priority filter
        if (priorityFilter !== 'all' && l.priority !== priorityFilter) return false;

        return true;
      })
      .sort((a, b) => {
        let mult = sortOrder === 'asc' ? 1 : -1;
        if (sortBy === 'value') return ((a.value || 0) - (b.value || 0)) * mult;
        if (sortBy === 'score') return ((a.aiScore || 0) - (b.aiScore || 0)) * mult;
        if (sortBy === 'name') return a.name.localeCompare(b.name) * mult;
        // default createdDate
        return (new Date(a.createdDate).getTime() - new Date(b.createdDate).getTime()) * mult;
      });
  }, [leads, searchQuery, stageFilter, sourceFilter, priorityFilter, sortBy, sortOrder]);

  // Checkbox helpers
  const isAllSelected =
    filteredLeads.length > 0 && filteredLeads.every((l) => selectedLeadIds.includes(l.id));

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedLeadIds([]);
    } else {
      setSelectedLeadIds(filteredLeads.map((l) => l.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedLeadIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="p-4 md:p-6 space-y-5 max-w-7xl mx-auto">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
            Lead Directory ({filteredLeads.length})
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Manage contacts, telecalling status, pipeline stages, and AI intelligence scoring.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => exportLeadsToCSV(filteredLeads)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#18181b] hover:bg-[#27272a] text-zinc-200 border border-[#27272a] rounded-lg transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" /> Export CSV
          </button>
          <button
            onClick={onOpenImportModal}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-[#18181b] hover:bg-[#27272a] text-zinc-200 border border-[#27272a] rounded-lg transition"
          >
            <Plus className="w-3.5 h-3.5" /> Import
          </button>
          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-white hover:bg-zinc-200 text-black rounded-lg shadow-sm transition"
          >
            <Plus className="w-4 h-4" /> Add Lead
          </button>
        </div>
      </div>

      {/* Stage Tabs Filter Bar */}
      <div className="flex items-center space-x-1 overflow-x-auto pb-1 border-b border-[#27272a] text-xs">
        {['all', 'new', 'contacted', 'qualifying', 'proposal_sent', 'negotiation', 'won', 'lost'].map(
          (stg) => {
            const count =
              stg === 'all' ? leads.length : leads.filter((l) => l.stage === stg).length;
            const isActive = stageFilter === stg;
            return (
              <button
                key={stg}
                onClick={() => setStageFilter(stg)}
                className={`px-3 py-2 rounded-lg font-medium transition flex items-center gap-1.5 whitespace-nowrap ${
                  isActive
                    ? 'bg-[#27272a] text-white shadow-sm font-semibold'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#18181b]'
                }`}
              >
                <span className="capitalize">{stg === 'all' ? 'All Leads' : stg.replace('_', ' ')}</span>
                <span
                  className={`px-1.5 py-0.2 text-[10px] rounded-full font-bold ${
                    isActive ? 'bg-white/20 text-white' : 'bg-[#18181b] text-zinc-400'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          }
        )}
      </div>

      {/* Secondary Filters & Sort */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#18181b] p-3 rounded-xl border border-[#27272a] text-xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Source Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-zinc-400">Source:</span>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="bg-[#09090b] text-zinc-200 border border-[#27272a] rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="all">All Sources</option>
              <option value="Website">Website</option>
              <option value="Inbound Call">Inbound Call</option>
              <option value="LinkedIn">LinkedIn</option>
              <option value="Google Ads">Google Ads</option>
              <option value="Referral">Referral</option>
              <option value="Cold Calling">Cold Calling</option>
              <option value="Event">Event</option>
            </select>
          </div>

          {/* Priority Filter */}
          <div className="flex items-center space-x-1">
            <span className="text-zinc-400">Priority:</span>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="bg-[#09090b] text-zinc-200 border border-[#27272a] rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="all">All Priorities</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>

        {/* Sort Controls */}
        <div className="flex items-center space-x-2">
          <span className="text-zinc-400">Sort By:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-[#09090b] text-zinc-200 border border-[#27272a] rounded-lg px-2.5 py-1.5 focus:outline-none"
          >
            <option value="createdDate">Date Created</option>
            <option value="value">Deal Value</option>
            <option value="score">AI Score</option>
            <option value="name">Name</option>
          </select>
          <button
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="p-1.5 bg-[#09090b] hover:bg-zinc-800 border border-[#27272a] rounded-lg text-zinc-300"
            title="Toggle Sort Direction"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Bulk Action Banner */}
      {selectedLeadIds.length > 0 && (
        <div className="flex items-center justify-between bg-[#18181b] border border-[#27272a] p-3 rounded-xl text-xs text-zinc-200">
          <div className="flex items-center space-x-2">
            <CheckSquare className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold">{selectedLeadIds.length} lead(s) selected</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onBatchScoreLeads(selectedLeadIds)}
              className="flex items-center gap-1 px-3 py-1 bg-emerald-500 text-black hover:bg-emerald-400 rounded font-semibold"
            >
              <Sparkles className="w-3.5 h-3.5" /> AI Batch Score
            </button>
            {(role === 'admin' || role === 'manager') && (
              <button
                onClick={() => {
                  onDeleteLeads(selectedLeadIds);
                  setSelectedLeadIds([]);
                }}
                className="flex items-center gap-1 px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded font-medium"
              >
                <Trash2 className="w-3.5 h-3.5" /> Delete Selected
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Leads Table */}
      <div className="bg-[#18181b] border border-[#27272a] rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#09090b] text-zinc-400 border-b border-[#27272a] font-semibold">
                <th className="p-3 w-10 text-center">
                  <button onClick={toggleSelectAll} className="text-zinc-400 hover:text-white">
                    {isAllSelected ? (
                      <CheckSquare className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="p-3">Lead / Company</th>
                <th className="p-3">Source & Priority</th>
                <th className="p-3">Stage</th>
                <th className="p-3">Est. Value</th>
                <th className="p-3">AI Score & Intent</th>
                <th className="p-3">Assigned To</th>
                <th className="p-3 text-right">Quick Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#27272a]">
              {filteredLeads.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-zinc-400">
                    No leads match your current search or filter criteria.
                  </td>
                </tr>
              ) : (
                filteredLeads.map((lead) => {
                  const isSelected = selectedLeadIds.includes(lead.id);
                  return (
                    <tr
                      key={lead.id}
                      className={`hover:bg-zinc-800/40 transition ${
                        isSelected ? 'bg-emerald-500/10' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="p-3 text-center">
                        <button
                          onClick={() => toggleSelectOne(lead.id)}
                          className="text-zinc-400 hover:text-white"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      {/* Name & Company */}
                      <td className="p-3">
                        <div
                          onClick={() => onSelectLead(lead)}
                          className="cursor-pointer space-y-0.5 group"
                        >
                          <div className="font-semibold text-zinc-200 group-hover:text-emerald-400 transition flex items-center gap-1.5">
                            {lead.name}
                          </div>
                          <div className="text-zinc-400 flex items-center gap-1.5 text-[11px]">
                            <Building className="w-3 h-3 text-zinc-500" />
                            {lead.company} {lead.role ? `(${lead.role})` : ''}
                          </div>
                        </div>
                      </td>

                      {/* Source & Priority */}
                      <td className="p-3">
                        <div className="space-y-1">
                          <span className="inline-block text-[11px] px-2 py-0.5 rounded bg-[#09090b] text-zinc-300 font-medium border border-[#27272a]">
                            {lead.source}
                          </span>
                          <div>
                            <span
                              className={`text-[10px] font-bold uppercase tracking-wider ${
                                lead.priority === 'high'
                                  ? 'text-rose-400'
                                  : lead.priority === 'medium'
                                  ? 'text-amber-400'
                                  : 'text-zinc-400'
                              }`}
                            >
                              {lead.priority} priority
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Stage Selector */}
                      <td className="p-3">
                        <select
                          value={lead.stage}
                          onChange={(e) =>
                            onUpdateLeadStage(lead.id, e.target.value as PipelineStage)
                          }
                          className={`text-xs px-2.5 py-1 rounded-full font-medium border focus:outline-none cursor-pointer ${
                            STAGE_BADGES[lead.stage]
                          }`}
                        >
                          {Object.keys(STAGE_LABELS).map((stgKey) => (
                            <option
                              key={stgKey}
                              value={stgKey}
                              className="bg-[#09090b] text-zinc-200"
                            >
                              {STAGE_LABELS[stgKey as PipelineStage]}
                            </option>
                          ))}
                        </select>
                      </td>

                      {/* Est Value */}
                      <td className="p-3">
                        <div className="font-semibold text-zinc-200">
                          ${(lead.value || 0).toLocaleString()}
                        </div>
                        {lead.budget ? (
                          <div className="text-[10px] text-zinc-500">
                            Budget: ${lead.budget.toLocaleString()}
                          </div>
                        ) : null}
                      </td>

                      {/* AI Score & Intent */}
                      <td className="p-3">
                        <div className="flex items-center space-x-1.5">
                          {lead.aiScore ? (
                            <span
                              className={`px-2 py-0.5 text-xs font-bold rounded-full flex items-center gap-1 ${
                                lead.aiIntent === 'Hot' || lead.aiScore >= 80
                                  ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                                  : lead.aiIntent === 'Warm' || lead.aiScore >= 50
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : 'bg-[#09090b] text-zinc-400 border border-[#27272a]'
                              }`}
                            >
                              <Flame className="w-3 h-3 text-amber-400" />
                              {lead.aiScore}/100
                            </span>
                          ) : (
                            <span className="text-[11px] text-zinc-500 italic">Not scored</span>
                          )}
                        </div>
                      </td>

                      {/* Assigned To */}
                      <td className="p-3 text-zinc-300">
                        <div className="flex items-center space-x-1.5">
                          <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{lead.assignedTo}</span>
                        </div>
                      </td>

                      {/* Quick Actions */}
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => onOpenCallLogModal(lead)}
                            className="p-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 transition"
                            title="Call & Log Activity"
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onSelectLead(lead)}
                            className="px-2.5 py-1 text-xs font-medium bg-[#09090b] hover:bg-zinc-800 text-zinc-200 rounded-lg border border-[#27272a] transition"
                          >
                            Details
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
