import React, { useState } from 'react';
import { X, Plus, Building, User, Mail, Phone, MapPin, DollarSign } from 'lucide-react';
import { Lead, LeadPriority, LeadSource, PipelineStage } from '../types';

interface AddLeadModalProps {
  onClose: () => void;
  onAddLead: (lead: Omit<Lead, 'id' | 'createdDate'>) => void;
}

export const AddLeadModal: React.FC<AddLeadModalProps> = ({ onClose, onAddLead }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [role, setRole] = useState('');
  const [location, setLocation] = useState('');
  const [source, setSource] = useState<LeadSource>('Website');
  const [stage, setStage] = useState<PipelineStage>('new');
  const [priority, setPriority] = useState<LeadPriority>('medium');
  const [value, setValue] = useState(15000);
  const [budget, setBudget] = useState(20000);
  const [assignedTo, setAssignedTo] = useState('Priya Sharma');
  const [tagsInput, setTagsInput] = useState('Inbound, High Priority');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !company) return;

    onAddLead({
      name,
      email,
      phone: phone || '+1 (555) 000-0000',
      company,
      role: role || undefined,
      location: location || undefined,
      source,
      stage,
      priority,
      value: Number(value) || 0,
      budget: Number(budget) || 0,
      assignedTo,
      tags: tagsInput
        ? tagsInput
            .split(',')
            .map((t) => t.trim())
            .filter((t) => t)
        : [],
      notes,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#18181b] border border-[#27272a] w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden text-zinc-100 my-auto">
        {/* Header */}
        <div className="bg-[#09090b] p-4 border-b border-[#27272a] flex items-center justify-between">
          <h2 className="text-base font-bold text-zinc-100 flex items-center gap-2">
            <Plus className="w-4 h-4 text-emerald-400" /> Create New Sales Lead
          </h2>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-zinc-300 font-medium block mb-1">Lead Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Rachel Adams"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-medium block mb-1">Company Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Acro Tech Ltd"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-zinc-300 font-medium block mb-1">Work Email *</label>
              <input
                type="email"
                required
                placeholder="rachel@acrotech.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-medium block mb-1">Phone Number</label>
              <input
                type="text"
                placeholder="+1 (555) 123-4567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-zinc-300 font-medium block mb-1">Job Title / Role</label>
              <input
                type="text"
                placeholder="e.g. Head of Sales"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-medium block mb-1">Lead Source</label>
              <select
                value={source}
                onChange={(e) => setSource(e.target.value as LeadSource)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              >
                <option value="Website">Website</option>
                <option value="Inbound Call">Inbound Call</option>
                <option value="LinkedIn">LinkedIn</option>
                <option value="Google Ads">Google Ads</option>
                <option value="Referral">Referral</option>
                <option value="Cold Calling">Cold Calling</option>
                <option value="Event">Event</option>
              </select>
            </div>

            <div>
              <label className="text-zinc-300 font-medium block mb-1">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as LeadPriority)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              >
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-zinc-300 font-medium block mb-1">Est. Deal Value ($)</label>
              <input
                type="number"
                value={value}
                onChange={(e) => setValue(Number(e.target.value))}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-medium block mb-1">Budget ($)</label>
              <input
                type="number"
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-medium block mb-1">Assigned Telecaller</label>
              <select
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              >
                <option value="Priya Sharma">Priya Sharma</option>
                <option value="David Miller">David Miller</option>
                <option value="Sarah Jenkins">Sarah Jenkins</option>
                <option value="Alex Vance">Alex Vance</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-zinc-300 font-medium block mb-1">Tags (Comma Separated)</label>
            <input
              type="text"
              placeholder="Enterprise, High Value, Q3 Goal"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-zinc-300 font-medium block mb-1">Initial Notes</label>
            <textarea
              rows={3}
              placeholder="Inquired about enterprise telecaller software integration..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-[#27272a]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#09090b] hover:bg-zinc-800 text-zinc-300 border border-[#27272a] rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold rounded-lg shadow-sm"
            >
              Create Lead
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
