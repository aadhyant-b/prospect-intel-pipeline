import React, { useState } from 'react';
import {
  FileText,
  Sparkles,
  UserCheck,
  Building2,
  Mail,
  Phone,
  DollarSign,
  Tag,
  CheckCircle2,
  Zap,
  Briefcase,
  Copy,
  Plus,
} from 'lucide-react';
import { Lead } from '../types';

interface SalesforceImportViewProps {
  onAddLead: (lead: Lead) => void;
  onOpenLeadDetail: (lead: Lead) => void;
}

export const SalesforceImportView: React.FC<SalesforceImportViewProps> = ({
  onAddLead,
  onOpenLeadDetail,
}) => {
  const [activeMode, setActiveMode] = useState<'raw_paste' | 'structured'>('raw_paste');
  const [prospectType, setProspectType] = useState<'salesforce' | 'self_prospected' | 'inbound'>('salesforce');

  // Raw Paste State
  const [rawText, setRawText] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState('');

  // Structured Field State (Optional)
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('');
  const [value, setValue] = useState(25000);
  const [fundingInfo, setFundingInfo] = useState('');
  const [notes, setNotes] = useState('');
  const [tagsInput, setTagsInput] = useState('Salesforce, High Priority');
  const [assignedTo, setAssignedTo] = useState('Sarah Jenkins');

  const sampleSalesforceDump = `Account Name: CloudScale AI Inc
Contact Name: Jonathan Vance
Title: Vice President of Engineering
Email: j.vance@cloudscale.ai
Phone: +1 (555) 982-3311
Estimated Deal Value: $65,000
Source: Salesforce Account SF-99823
Notes: Recently completed $28M Series A funding led by Sequoia. Looking for automated telecalling workflow and CRM routing for 45 account executives before Q4 expansion.`;

  const handlePasteSample = () => {
    setRawText(sampleSalesforceDump);
  };

  const handleParseRawLead = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rawText.trim()) return;

    setIsParsing(true);
    setParseError('');

    try {
      const res = await fetch('/api/gemini/parse-raw-lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText, assignedTo }),
      });

      const data = await res.json();
      if (data.success && data.lead) {
        const newLead: Lead = {
          ...data.lead,
          id: `lead_${Date.now()}`,
          prospectType,
          cadenceStep: 1,
          cadenceName: 'Salesforce Pursuit Cadence',
        };
        onAddLead(newLead);
        setRawText('');
        onOpenLeadDetail(newLead);
      } else {
        setParseError(data.error || 'Failed to parse raw lead text');
      }
    } catch (err: any) {
      console.error(err);
      setParseError(err.message || 'Error communicating with AI parser');
    } finally {
      setIsParsing(false);
    }
  };

  const handleStructuredSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !company) return;

    const newLead: Lead = {
      id: `lead_${Date.now()}`,
      name,
      company,
      email: email || `${name.toLowerCase().replace(/\s+/g, '.')}@${company.toLowerCase().replace(/\s+/g, '')}.com`,
      phone: phone || '+1 (555) 000-0000',
      role: role || 'Decision Maker',
      source: prospectType === 'salesforce' ? 'Salesforce Import' : prospectType === 'inbound' ? 'Inbound Call' : 'Cold Calling',
      stage: 'new',
      priority: 'high',
      value: Number(value) || 25000,
      assignedTo,
      fundingInfo: fundingInfo || undefined,
      tags: tagsInput.split(',').map((t) => t.trim()).filter(Boolean),
      notes,
      createdDate: new Date().toISOString().split('T')[0],
      nextFollowUpDate: new Date().toISOString().split('T')[0],
      prospectType,
      cadenceStep: 1,
      phoneLookupStatus: phone ? 'verified' : 'lookup_needed',
    };

    onAddLead(newLead);
    onOpenLeadDetail(newLead);
    // Reset form
    setName('');
    setCompany('');
    setEmail('');
    setPhone('');
    setRole('');
    setFundingInfo('');
    setNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#18181b] border border-[#27272a] p-5 rounded-2xl">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Zap className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-zinc-100">
              Salesforce & Unstructured Lead Import Engine
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-1 max-w-2xl">
            Copy-paste raw text from Salesforce accounts, email threads, or LinkedIn profiles. Gemini AI automatically extracts contact details, funding rounds, and prepares instant sales research.
          </p>
        </div>

        {/* Prospect Category Selector */}
        <div className="flex items-center bg-[#09090b] p-1 rounded-xl border border-[#27272a] text-xs">
          <button
            onClick={() => setProspectType('salesforce')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition ${
              prospectType === 'salesforce'
                ? 'bg-emerald-500 text-black shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Salesforce Lead
          </button>
          <button
            onClick={() => setProspectType('self_prospected')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition ${
              prospectType === 'self_prospected'
                ? 'bg-emerald-500 text-black shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Self-Prospected
          </button>
          <button
            onClick={() => setProspectType('inbound')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition ${
              prospectType === 'inbound'
                ? 'bg-emerald-500 text-black shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Inbound Request
          </button>
        </div>
      </div>

      {/* Input Mode Tabs */}
      <div className="flex border-b border-[#27272a] text-xs font-semibold space-x-4">
        <button
          onClick={() => setActiveMode('raw_paste')}
          className={`pb-3 border-b-2 flex items-center gap-2 transition ${
            activeMode === 'raw_paste'
              ? 'border-emerald-400 text-emerald-400 font-bold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Sparkles className="w-4 h-4 text-emerald-400" /> Option A: Raw Salesforce / Text Paste (AI AI Auto-Extract)
        </button>
        <button
          onClick={() => setActiveMode('structured')}
          className={`pb-3 border-b-2 flex items-center gap-2 transition ${
            activeMode === 'structured'
              ? 'border-emerald-400 text-emerald-400 font-bold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <FileText className="w-4 h-4 text-zinc-400" /> Option B: Structured Form Fields (Optional)
        </button>
      </div>

      {/* MODE 1: RAW TEXT PASTE */}
      {activeMode === 'raw_paste' && (
        <form onSubmit={handleParseRawLead} className="bg-[#18181b] border border-[#27272a] p-6 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                <Copy className="w-4 h-4 text-emerald-400" /> Paste Salesforce Account / Email Text
              </h3>
              <p className="text-xs text-zinc-400">
                Paste any unstructured snippet. The AI parser extracts contact info, value, funding, and creates a pursuit workspace.
              </p>
            </div>
            <button
              type="button"
              onClick={handlePasteSample}
              className="text-xs text-emerald-400 hover:underline font-semibold flex items-center gap-1"
            >
              <Zap className="w-3.5 h-3.5" /> Paste Sample Salesforce Dump
            </button>
          </div>

          <textarea
            rows={8}
            required
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
            placeholder="e.g. Account Name: CloudScale AI Inc&#10;Contact Name: Jonathan Vance&#10;Title: VP of Engineering&#10;Email: j.vance@cloudscale.ai&#10;Phone: +1 (555) 982-3311&#10;Deal Value: $65,000&#10;Notes: Recently completed $28M Series A funding..."
            className="w-full bg-[#09090b] text-zinc-100 font-mono text-xs border border-[#27272a] rounded-xl p-4 focus:outline-none focus:ring-1 focus:ring-emerald-500 leading-relaxed"
          />

          {parseError && (
            <div className="p-3 bg-rose-950/20 border border-rose-500/30 text-rose-300 text-xs rounded-xl font-semibold">
              {parseError}
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t border-[#27272a]">
            <div className="flex items-center space-x-2 text-xs text-zinc-400">
              <span>Assign to Telecaller:</span>
              <select
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                className="bg-[#09090b] text-zinc-200 border border-[#27272a] rounded-lg px-2.5 py-1 focus:outline-none"
              >
                <option value="Sarah Jenkins">Sarah Jenkins (Admin)</option>
                <option value="Alex Vance">Alex Vance (Manager)</option>
                <option value="Priya Sharma">Priya Sharma (Telecaller)</option>
                <option value="David Miller">David Miller (Telecaller)</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isParsing || !rawText.trim()}
              className="px-6 py-2.5 bg-white hover:bg-zinc-200 text-black font-semibold text-xs rounded-xl shadow-sm transition flex items-center gap-2 disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-emerald-500" />
              {isParsing ? 'Parsing & Researching Lead...' : 'Extract Lead & Launch Pursuit Workspace'}
            </button>
          </div>
        </form>
      )}

      {/* MODE 2: STRUCTURED FORM FIELDS */}
      {activeMode === 'structured' && (
        <form onSubmit={handleStructuredSubmit} className="bg-[#18181b] border border-[#27272a] p-6 rounded-2xl space-y-4 text-xs">
          <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <Plus className="w-4 h-4 text-emerald-400" /> Enter Prospect Details Manually
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Lead Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Elena Rostova"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Company Name *</label>
              <input
                type="text"
                required
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="e.g. Nexus Cloud Systems"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Work Email (Optional)</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="elena@nexuscloud.tech"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Phone Number (Optional)</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 (555) 234-8901"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Job Title / Role</label>
              <input
                type="text"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                placeholder="e.g. VP of Infrastructure"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Estimated Deal Value ($)</label>
              <input
                type="number"
                value={value}
                onChange={(e) => setValue(Number(e.target.value))}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Funding Info / Growth Stage</label>
              <input
                type="text"
                value={fundingInfo}
                onChange={(e) => setFundingInfo(e.target.value)}
                placeholder="e.g. $38M Series B led by Benchmark"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Assigned Telecaller</label>
              <select
                value={assignedTo}
                onChange={(e) => setAssignedTo(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
              >
                <option value="Sarah Jenkins">Sarah Jenkins (Admin)</option>
                <option value="Alex Vance">Alex Vance (Manager)</option>
                <option value="Priya Sharma">Priya Sharma (Telecaller)</option>
                <option value="David Miller">David Miller (Telecaller)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-zinc-300 font-semibold block mb-1">Notes & Context</label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Primary interests, timeline, and requirements..."
              className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
            />
          </div>

          <div className="flex justify-end pt-2 border-t border-[#27272a]">
            <button
              type="submit"
              className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold text-xs rounded-xl shadow-sm transition"
            >
              Create Lead & Launch Pursuit Workspace
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
