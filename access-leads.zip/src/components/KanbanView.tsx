import React from 'react';
import {
  Building,
  PhoneCall,
  ChevronRight,
  ChevronLeft,
  Flame,
  Plus,
  DollarSign,
  UserCheck,
} from 'lucide-react';
import { Lead, PipelineStage } from '../types';

interface KanbanViewProps {
  leads: Lead[];
  onSelectLead: (lead: Lead) => void;
  onUpdateLeadStage: (leadId: string, newStage: PipelineStage) => void;
  onOpenAddModal: () => void;
  onOpenCallLogModal: (lead: Lead) => void;
}

const KANBAN_STAGES: { id: PipelineStage; label: string; color: string }[] = [
  { id: 'new', label: 'New Lead', color: 'border-t-blue-500' },
  { id: 'contacted', label: 'Contacted', color: 'border-t-cyan-500' },
  { id: 'qualifying', label: 'Qualifying', color: 'border-t-purple-500' },
  { id: 'proposal_sent', label: 'Proposal Sent', color: 'border-t-pink-500' },
  { id: 'negotiation', label: 'Negotiation', color: 'border-t-amber-500' },
  { id: 'won', label: 'Closed Won', color: 'border-t-emerald-500' },
  { id: 'lost', label: 'Closed Lost', color: 'border-t-rose-500' },
];

const STAGE_ORDER: PipelineStage[] = [
  'new',
  'contacted',
  'qualifying',
  'proposal_sent',
  'negotiation',
  'won',
  'lost',
];

export const KanbanView: React.FC<KanbanViewProps> = ({
  leads,
  onSelectLead,
  onUpdateLeadStage,
  onOpenAddModal,
  onOpenCallLogModal,
}) => {
  const getStageTotalValue = (stage: PipelineStage) => {
    return leads
      .filter((l) => l.stage === stage)
      .reduce((sum, l) => sum + (l.value || 0), 0);
  };

  const moveStage = (lead: Lead, direction: 'next' | 'prev') => {
    const currentIndex = STAGE_ORDER.indexOf(lead.stage);
    if (direction === 'next' && currentIndex < STAGE_ORDER.length - 1) {
      onUpdateLeadStage(lead.id, STAGE_ORDER[currentIndex + 1]);
    } else if (direction === 'prev' && currentIndex > 0) {
      onUpdateLeadStage(lead.id, STAGE_ORDER[currentIndex - 1]);
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Interactive Pipeline Board</h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Visualize deal flow, stage values, and progress leads seamlessly.
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-white hover:bg-zinc-200 text-black rounded-lg shadow-sm transition"
        >
          <Plus className="w-4 h-4" /> Add Lead
        </button>
      </div>

      {/* Kanban Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-3.5 items-start overflow-x-auto pb-4">
        {KANBAN_STAGES.map((stage) => {
          const stageLeads = leads.filter((l) => l.stage === stage.id);
          const totalVal = getStageTotalValue(stage.id);

          return (
            <div
              key={stage.id}
              className={`bg-[#09090b] border border-[#27272a] rounded-2xl border-t-4 ${stage.color} p-3 space-y-3 flex flex-col min-w-[230px]`}
            >
              {/* Column Header */}
              <div className="flex items-center justify-between border-b border-[#27272a] pb-2">
                <div className="flex items-center space-x-1.5">
                  <span className="font-bold text-xs text-zinc-200">{stage.label}</span>
                  <span className="px-1.5 py-0.2 text-[10px] bg-[#18181b] text-zinc-400 font-bold rounded-full border border-[#27272a]">
                    {stageLeads.length}
                  </span>
                </div>
                <span className="text-[11px] font-mono font-semibold text-emerald-400">
                  ${totalVal.toLocaleString()}
                </span>
              </div>

              {/* Cards List */}
              <div className="space-y-2.5 min-h-[300px]">
                {stageLeads.length === 0 ? (
                  <div className="text-center py-8 text-zinc-600 text-[11px] border border-dashed border-[#27272a] rounded-xl">
                    No leads in stage
                  </div>
                ) : (
                  stageLeads.map((lead) => {
                    const stageIndex = STAGE_ORDER.indexOf(lead.stage);

                    return (
                      <div
                        key={lead.id}
                        className="bg-[#18181b] hover:bg-zinc-800/60 border border-[#27272a] p-3 rounded-xl shadow-sm space-y-2 group transition"
                      >
                        {/* Title & Score */}
                        <div className="flex items-start justify-between">
                          <div
                            onClick={() => onSelectLead(lead)}
                            className="cursor-pointer space-y-0.5 flex-1 pr-2"
                          >
                            <h4 className="font-semibold text-xs text-zinc-100 group-hover:text-emerald-400 transition line-clamp-1">
                              {lead.name}
                            </h4>
                            <p className="text-[11px] text-zinc-400 flex items-center gap-1">
                              <Building className="w-3 h-3 text-zinc-500" /> {lead.company}
                            </p>
                          </div>

                          {lead.aiScore && (
                            <span
                              className={`px-1.5 py-0.5 text-[10px] font-bold rounded-md flex items-center gap-0.5 ${
                                lead.aiScore >= 80
                                  ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              }`}
                            >
                              <Flame className="w-2.5 h-2.5 text-amber-400" />
                              {lead.aiScore}
                            </span>
                          )}
                        </div>

                        {/* Value & Source */}
                        <div className="flex items-center justify-between text-[11px] pt-1 border-t border-[#27272a]">
                          <span className="font-bold text-emerald-400">
                            ${(lead.value || 0).toLocaleString()}
                          </span>
                          <span className="text-[10px] text-zinc-400 bg-[#09090b] px-1.5 py-0.5 rounded border border-[#27272a]">
                            {lead.source}
                          </span>
                        </div>

                        {/* Assignee & Controls */}
                        <div className="flex items-center justify-between text-[10px] text-zinc-400 pt-1">
                          <span className="flex items-center gap-1">
                            <UserCheck className="w-3 h-3 text-emerald-400" />
                            {lead.assignedTo.split(' ')[0]}
                          </span>

                          <div className="flex items-center space-x-1">
                            <button
                              onClick={() => onOpenCallLogModal(lead)}
                              className="p-1 rounded bg-[#09090b] hover:bg-emerald-500 text-zinc-300 hover:text-black border border-[#27272a] transition"
                              title="Call Lead"
                            >
                              <PhoneCall className="w-3 h-3" />
                            </button>
                            {stageIndex > 0 && (
                              <button
                                onClick={() => moveStage(lead, 'prev')}
                                className="p-1 rounded bg-[#09090b] hover:bg-zinc-800 text-zinc-300 border border-[#27272a] transition"
                                title="Move Backward"
                              >
                                <ChevronLeft className="w-3 h-3" />
                              </button>
                            )}
                            {stageIndex < STAGE_ORDER.length - 1 && (
                              <button
                                onClick={() => moveStage(lead, 'next')}
                                className="p-1 rounded bg-[#09090b] hover:bg-[#27272a] text-zinc-300 hover:text-white border border-[#27272a] transition"
                                title="Move Forward"
                              >
                                <ChevronRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
