import React, { useState } from 'react';
import {
  ShieldCheck,
  UserCheck,
  Users,
  Lock,
  Plus,
  CheckCircle2,
  XCircle,
  Settings,
  Zap,
} from 'lucide-react';
import { Role, TeamMember } from '../types';

interface TeamAccessViewProps {
  team: TeamMember[];
  onUpdateRole: (memberId: string, newRole: Role) => void;
  onAddTeamMember: (member: Omit<TeamMember, 'id'>) => void;
}

export const TeamAccessView: React.FC<TeamAccessViewProps> = ({
  team,
  onUpdateRole,
  onAddTeamMember,
}) => {
  const [distributionMode, setDistributionMode] = useState<'round_robin' | 'by_source' | 'manual'>('round_robin');
  const [showAddMember, setShowAddMember] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<Role>('telecaller');

  const handleCreateMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail) return;
    onAddTeamMember({
      name: newName,
      email: newEmail,
      role: newRole,
      avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150`,
      assignedLeadsCount: 0,
      callsToday: 0,
      dealsClosed: 0,
      revenueClosed: 0,
      conversionRate: 0,
    });
    setNewName('');
    setNewEmail('');
    setShowAddMember(false);
  };

  const PERMISSIONS_MATRIX = [
    { feature: 'View All Company Leads', admin: true, manager: true, telecaller: false },
    { feature: 'Access Assigned Leads Only', admin: true, manager: true, telecaller: true },
    { feature: 'Log Calls & Activity Notes', admin: true, manager: true, telecaller: true },
    { feature: 'Export Directory to CSV', admin: true, manager: true, telecaller: false },
    { feature: 'Delete / Bulk Delete Leads', admin: true, manager: false, telecaller: false },
    { feature: 'Reassign Leads to Team', admin: true, manager: true, telecaller: false },
    { feature: 'Trigger Gemini AI Lead Scoring', admin: true, manager: true, telecaller: true },
    { feature: 'Modify Team Roles & Access', admin: true, manager: false, telecaller: false },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" /> Access Leads & Team Authorization
          </h1>
          <p className="text-xs text-zinc-400 mt-0.5">
            Role-based access control (RBAC), telecaller routing rules, and user administration.
          </p>
        </div>

        <button
          onClick={() => setShowAddMember(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-white hover:bg-zinc-200 text-black rounded-lg shadow-sm transition"
        >
          <Plus className="w-4 h-4" /> Add Team Member
        </button>
      </div>

      {/* Add Member Form Modal / Panel */}
      {showAddMember && (
        <form
          onSubmit={handleCreateMember}
          className="bg-[#18181b] border border-[#27272a] p-4 rounded-2xl space-y-3 text-xs"
        >
          <h3 className="font-bold text-zinc-100 text-sm">Add New Team Member</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-zinc-400 font-medium block mb-1">Full Name</label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Jason Vance"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-zinc-400 font-medium block mb-1">Work Email</label>
              <input
                type="email"
                required
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="jason.v@accessleads.io"
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>
            <div>
              <label className="text-zinc-400 font-medium block mb-1">Role</label>
              <select
                value={newRole}
                onChange={(e) => setNewRole(e.target.value as Role)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              >
                <option value="telecaller">Telecaller / Rep</option>
                <option value="manager">Sales Manager</option>
                <option value="admin">System Admin</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end space-x-2 pt-2">
            <button
              type="button"
              onClick={() => setShowAddMember(false)}
              className="px-3 py-1.5 bg-[#09090b] text-zinc-300 border border-[#27272a] rounded hover:bg-zinc-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-emerald-500 text-black font-semibold rounded hover:bg-emerald-400"
            >
              Save Member
            </button>
          </div>
        </form>
      )}

      {/* Auto Lead Routing Rule Setup */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-3">
        <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" /> Lead Distribution & Auto-Assignment Engine
        </h3>
        <p className="text-xs text-zinc-400">
          Determine how new inbound leads from Website, Forms, and Ads are distributed among telecallers.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <button
            onClick={() => setDistributionMode('round_robin')}
            className={`p-3 rounded-xl border text-left transition text-xs space-y-1 ${
              distributionMode === 'round_robin'
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-semibold'
                : 'bg-[#09090b] border-[#27272a] text-zinc-400 hover:bg-zinc-800'
            }`}
          >
            <div className="font-bold text-zinc-200">Round-Robin Equal Split</div>
            <p className="text-[11px] text-zinc-400 font-normal">
              Distributes incoming leads sequentially among active telecallers.
            </p>
          </button>

          <button
            onClick={() => setDistributionMode('by_source')}
            className={`p-3 rounded-xl border text-left transition text-xs space-y-1 ${
              distributionMode === 'by_source'
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-semibold'
                : 'bg-[#09090b] border-[#27272a] text-zinc-400 hover:bg-zinc-800'
            }`}
          >
            <div className="font-bold text-zinc-200">By Lead Source Specialty</div>
            <p className="text-[11px] text-zinc-400 font-normal">
              Routes LinkedIn leads to Senior Reps and Inbound Calls to Telecalling Desk.
            </p>
          </button>

          <button
            onClick={() => setDistributionMode('manual')}
            className={`p-3 rounded-xl border text-left transition text-xs space-y-1 ${
              distributionMode === 'manual'
                ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 font-semibold'
                : 'bg-[#09090b] border-[#27272a] text-zinc-400 hover:bg-zinc-800'
            }`}
          >
            <div className="font-bold text-zinc-200">Manual Manager Claim</div>
            <p className="text-[11px] text-zinc-400 font-normal">
              Leads sit in Unassigned pool until claimed by telecallers or assigned by Manager.
            </p>
          </button>
        </div>
      </div>

      {/* Team Roster Table */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-4">
        <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
          <Users className="w-4 h-4 text-emerald-400" /> Active Team Roster & Roles
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#27272a] text-zinc-400 font-semibold">
                <th className="pb-3">User</th>
                <th className="pb-3">Email</th>
                <th className="pb-3">Current Role</th>
                <th className="pb-3">Assigned Leads</th>
                <th className="pb-3 text-right">Access Controls</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#27272a]">
              {team.map((member) => (
                <tr key={member.id} className="hover:bg-zinc-800/40 transition">
                  <td className="py-3 flex items-center space-x-2">
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-8 h-8 rounded-full object-cover border border-[#27272a]"
                    />
                    <div>
                      <div className="font-semibold text-zinc-200">{member.name}</div>
                    </div>
                  </td>
                  <td className="py-3 text-zinc-400 font-mono">{member.email}</td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-semibold capitalize ${
                        member.role === 'admin'
                          ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                          : member.role === 'manager'
                          ? 'bg-purple-500/10 text-purple-300 border border-purple-500/20'
                          : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                      }`}
                    >
                      {member.role}
                    </span>
                  </td>
                  <td className="py-3 font-semibold text-zinc-300">
                    {member.assignedLeadsCount} active
                  </td>
                  <td className="py-3 text-right">
                    <select
                      value={member.role}
                      onChange={(e) => onUpdateRole(member.id, e.target.value as Role)}
                      className="bg-[#09090b] text-zinc-200 border border-[#27272a] rounded-lg px-2.5 py-1 text-xs focus:outline-none"
                    >
                      <option value="telecaller">Set Telecaller</option>
                      <option value="manager">Set Manager</option>
                      <option value="admin">Set Admin</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Role Permission Matrix */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-4">
        <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
          <Lock className="w-4 h-4 text-cyan-400" /> Security & Role Permission Matrix
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#27272a] text-zinc-400 font-semibold">
                <th className="pb-2">Capability / Privilege</th>
                <th className="pb-2 text-center">Admin</th>
                <th className="pb-2 text-center">Sales Manager</th>
                <th className="pb-2 text-center">Telecaller / Rep</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#27272a]">
              {PERMISSIONS_MATRIX.map((perm, idx) => (
                <tr key={idx} className="hover:bg-zinc-800/40">
                  <td className="py-2.5 text-zinc-300 font-medium">{perm.feature}</td>
                  <td className="py-2.5 text-center">
                    {perm.admin ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-zinc-600 mx-auto" />
                    )}
                  </td>
                  <td className="py-2.5 text-center">
                    {perm.manager ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-zinc-600 mx-auto" />
                    )}
                  </td>
                  <td className="py-2.5 text-center">
                    {perm.telecaller ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-zinc-600 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
