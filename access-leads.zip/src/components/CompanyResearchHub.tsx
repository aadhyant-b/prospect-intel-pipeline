import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  Building2,
  DollarSign,
  Newspaper,
  Layers,
  Phone,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  TrendingUp,
  Cpu,
  Globe,
  Zap,
} from 'lucide-react';
import { Lead, CompanyResearch } from '../types';

interface CompanyResearchHubProps {
  leads: Lead[];
  onUpdateLeadResearch: (leadId: string, research: CompanyResearch) => void;
  onOpenLeadDetail: (lead: Lead) => void;
}

export const CompanyResearchHub: React.FC<CompanyResearchHubProps> = ({
  leads,
  onUpdateLeadResearch,
  onOpenLeadDetail,
}) => {
  const [selectedLeadId, setSelectedLeadId] = useState<string>(leads[0]?.id || '');
  const [customCompanyInput, setCustomCompanyInput] = useState('');
  const [isResearching, setIsResearching] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const activeLead = leads.find((l) => l.id === selectedLeadId) || leads[0];

  const handleTriggerResearch = async (companyName: string, leadToUpdate?: Lead) => {
    if (!companyName.trim()) return;

    setIsResearching(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/gemini/research-company', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          company: companyName,
          leadName: leadToUpdate?.name,
          role: leadToUpdate?.role,
          notes: leadToUpdate?.notes,
        }),
      });

      const data = await res.json();
      if (data.success && data.research) {
        if (leadToUpdate) {
          onUpdateLeadResearch(leadToUpdate.id, data.research);
        }
      } else {
        setErrorMsg(data.error || 'Failed to research company');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error executing research request');
    } finally {
      setIsResearching(false);
    }
  };

  const currentResearch = activeLead?.companyResearch;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Newspaper className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-zinc-100">
              Source-Grounded Corporate Intelligence & News Discovery
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Discover funding milestones, press releases, provider tech stack classifications, and direct phone dialer verification.
          </p>
        </div>

        {/* Lead Selector Dropdown */}
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-zinc-400">Select Pursuit Target:</span>
          <select
            value={selectedLeadId}
            onChange={(e) => setSelectedLeadId(e.target.value)}
            className="bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl px-3 py-2 font-semibold focus:outline-none"
          >
            {leads.map((lead) => (
              <option key={lead.id} value={lead.id}>
                {lead.company} ({lead.name})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Target Research Panel */}
      {activeLead && (
        <div className="space-y-6">
          {/* Target Overview Bar */}
          <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl font-bold text-lg">
                {activeLead.company.substring(0, 2).toUpperCase()}
              </div>
              <div>
                <h2 className="text-base font-bold text-zinc-100">{activeLead.company}</h2>
                <p className="text-zinc-400">
                  Key Decision Maker: <strong className="text-zinc-200">{activeLead.name}</strong> ({activeLead.role || 'Executive'})
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => handleTriggerResearch(activeLead.company, activeLead)}
                disabled={isResearching}
                className="px-4 py-2 bg-white hover:bg-zinc-200 text-black font-semibold rounded-xl transition flex items-center gap-1.5 disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4 text-emerald-500" />
                {isResearching ? 'Searching Press Releases...' : 'Re-Run Live Corporate Audit'}
              </button>

              <button
                onClick={() => onOpenLeadDetail(activeLead)}
                className="px-4 py-2 bg-[#09090b] hover:bg-[#27272a] text-zinc-200 border border-[#27272a] font-semibold rounded-xl transition"
              >
                View Full Lead Tabs
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-950/20 border border-rose-500/30 text-rose-300 text-xs rounded-xl font-semibold">
              {errorMsg}
            </div>
          )}

          {/* Research Results Grid */}
          {!currentResearch ? (
            <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-10 text-center space-y-3">
              <Sparkles className="w-10 h-10 text-emerald-400 mx-auto" />
              <h3 className="font-bold text-zinc-100 text-sm">No Corporate Research Generated Yet</h3>
              <p className="text-xs text-zinc-400 max-w-md mx-auto">
                Click "Re-Run Live Corporate Audit" above to discover funding rounds, latest press releases, provider stack, and phone dialer numbers.
              </p>
              <button
                onClick={() => handleTriggerResearch(activeLead.company, activeLead)}
                disabled={isResearching}
                className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl transition shadow"
              >
                {isResearching ? 'Analyzing Company...' : 'Generate Research Now'}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: Funding & Press Releases */}
              <div className="lg:col-span-2 space-y-6">
                {/* 1. Latest Press Releases */}
                <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-4">
                  <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                    <Newspaper className="w-4 h-4 text-emerald-400" /> Press Releases & Company News
                  </h3>

                  <div className="space-y-3">
                    {currentResearch.latestPressReleases?.map((pr, idx) => (
                      <div
                        key={idx}
                        className="bg-[#09090b] border border-[#27272a] p-4 rounded-xl space-y-2 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-zinc-100">{pr.title}</span>
                          <span className="text-[10px] text-zinc-500">{pr.date}</span>
                        </div>
                        <p className="text-zinc-400 text-[11px]">{pr.summary}</p>
                        <div className="p-2 bg-emerald-950/20 border border-emerald-500/20 text-emerald-300 rounded-lg text-[11px]">
                          <strong>Strategic Outreach Hook:</strong> {pr.strategicAngle}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. Press Release Analysis */}
                <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-2 text-xs">
                  <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-400" /> AI Executive Analysis & Strategic Pain Points
                  </h3>
                  <p className="text-zinc-300 leading-relaxed bg-[#09090b] p-4 rounded-xl border border-[#27272a]">
                    {currentResearch.pressReleaseAnalysis}
                  </p>
                </div>
              </div>

              {/* Right Column: Funding, Providers & Phone Verification */}
              <div className="space-y-6">
                {/* 1. Phone Verification Lookup */}
                <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-3 text-xs">
                  <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                    <Phone className="w-4 h-4 text-emerald-400" /> Phone Dialer & Direct Line
                  </h3>

                  {currentResearch.phoneLookupResult ? (
                    <div className="bg-[#09090b] p-3 rounded-xl border border-[#27272a] space-y-1">
                      <div className="text-base font-bold text-emerald-400 font-mono">
                        {currentResearch.phoneLookupResult.number}
                      </div>
                      <div className="text-zinc-400 text-[11px]">
                        Status: <strong className="text-zinc-200">{currentResearch.phoneLookupResult.confidence}</strong>
                      </div>
                      <div className="text-zinc-500 text-[10px]">
                        Source: {currentResearch.phoneLookupResult.source}
                      </div>
                    </div>
                  ) : (
                    <p className="text-zinc-500">No verified direct phone found yet.</p>
                  )}
                </div>

                {/* 2. Funding Rounds */}
                <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-3 text-xs">
                  <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-400" /> Capital & Funding History
                  </h3>

                  <div className="space-y-2">
                    {currentResearch.fundingRounds?.map((f, i) => (
                      <div key={i} className="bg-[#09090b] p-3 rounded-xl border border-[#27272a] flex items-center justify-between">
                        <div>
                          <div className="font-bold text-zinc-200">{f.round} ({f.amount})</div>
                          <div className="text-[10px] text-zinc-500">{f.investors || 'Venture Backed'}</div>
                        </div>
                        <span className="text-[10px] text-emerald-400 font-bold">{f.date}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. Provider Classification */}
                <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-3 text-xs">
                  <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-400" /> Provider & Tech Stack Classification
                  </h3>

                  <div className="space-y-2">
                    {currentResearch.providerClassification?.map((p, idx) => (
                      <div key={idx} className="bg-[#09090b] p-2.5 rounded-xl border border-[#27272a] flex items-center justify-between">
                        <span className="text-zinc-400 text-[11px]">{p.category}</span>
                        <span className="font-semibold text-zinc-200">{p.provider}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
