import React, { useState } from 'react';
import {
  X,
  Building,
  Mail,
  Phone,
  Calendar,
  DollarSign,
  Sparkles,
  Flame,
  PhoneCall,
  Clock,
  Send,
  FileText,
  Copy,
  Check,
  UserCheck,
  Tag,
  AlertTriangle,
  Plus,
  Newspaper,
  TrendingUp,
  Layers,
  BookOpen,
  Zap,
} from 'lucide-react';
import {
  Lead,
  Activity,
  Task,
  AIAnalysisResult,
  AIEmailDraft,
  AICallScript,
  PipelineStage,
  StylePreset,
} from '../types';

interface LeadDetailModalProps {
  lead: Lead | null;
  activities: Activity[];
  tasks: Task[];
  styles: StylePreset[];
  onClose: () => void;
  onUpdateLeadStage: (leadId: string, stage: PipelineStage) => void;
  onOpenCallLogModal: (lead: Lead) => void;
  onAddTask: (task: Omit<Task, 'id'>) => void;
  onUpdateLeadResearch?: (leadId: string, research: any) => void;
}

export const LeadDetailModal: React.FC<LeadDetailModalProps> = ({
  lead,
  activities,
  tasks,
  styles,
  onClose,
  onUpdateLeadStage,
  onOpenCallLogModal,
  onAddTask,
  onUpdateLeadResearch,
}) => {
  if (!lead) return null;

  const [activeTab, setActiveTab] = useState<
    'overview' | 'research' | 'selling_angles' | 'ai_email' | 'ai_script' | 'timeline' | 'tasks'
  >('research');

  // AI Lead Scoring State
  const [isScoring, setIsScoring] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(
    lead.aiScore
      ? {
          score: lead.aiScore,
          intent: lead.aiIntent || 'Warm',
          summary: lead.aiSummary || 'Analyzed from previous interactions.',
          buyingSignals: [
            `Allocated budget of $${lead.value.toLocaleString()}`,
            `Source: ${lead.source}`,
            'Decision maker involvement',
          ],
          keyRisks: ['Timeline dependency on compliance review'],
          recommendedNextSteps: [
            'Send custom proposal deck',
            'Schedule decision call with VP',
          ],
        }
      : null
  );

  // Company Research State
  const [isResearching, setIsResearching] = useState(false);

  // Email State with Style Selector
  const [selectedStyleName, setSelectedStyleName] = useState<string>(styles[0]?.name || 'Concise C-Level');
  const [emailObjective, setEmailObjective] = useState('Schedule a 15-minute decision call');
  const [isGeneratingEmail, setIsGeneratingEmail] = useState(false);
  const [aiEmail, setAiEmail] = useState<AIEmailDraft | null>(null);
  const [copiedEmail, setCopiedEmail] = useState(false);

  // Call script state
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [aiScript, setAiScript] = useState<AICallScript | null>(null);

  // New task state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDate, setNewTaskDate] = useState('');

  const leadActivities = activities.filter((a) => a.leadId === lead.id);
  const leadTasks = tasks.filter((t) => t.leadId === lead.id);

  // Run Corporate Deep Research API
  const handleRunResearch = async () => {
    setIsResearching(true);
    try {
      const res = await fetch('/api/gemini/research-company', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          company: lead.company,
          leadName: lead.name,
          role: lead.role,
          notes: lead.notes,
        }),
      });
      const data = await res.json();
      if (data.success && data.research && onUpdateLeadResearch) {
        onUpdateLeadResearch(lead.id, data.research);
      }
    } catch (err) {
      console.error('Research error:', err);
    } finally {
      setIsResearching(false);
    }
  };

  // Trigger AI Lead Score API
  const handleScoreLead = async () => {
    setIsScoring(true);
    try {
      const res = await fetch('/api/gemini/score-lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead, activities: leadActivities }),
      });
      const data = await res.json();
      if (data.success && data.analysis) {
        setAiAnalysis(data.analysis);
      }
    } catch (err) {
      console.error('Failed to score lead:', err);
    } finally {
      setIsScoring(false);
    }
  };

  // Trigger AI Styled Email Generator
  const handleGenerateEmail = async () => {
    setIsGeneratingEmail(true);
    const activeStyleObj = styles.find((s) => s.name === selectedStyleName);
    try {
      const res = await fetch('/api/gemini/generate-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead,
          styleName: selectedStyleName,
          styleInstructions: activeStyleObj?.promptInstructions,
          tone: activeStyleObj?.tone || 'Professional',
          objective: emailObjective,
        }),
      });
      const data = await res.json();
      if (data.success && data.email) {
        setAiEmail(data.email);
      }
    } catch (err) {
      console.error('Failed to generate email:', err);
    } finally {
      setIsGeneratingEmail(false);
    }
  };

  // Trigger AI Call Script API
  const handleGenerateScript = async () => {
    setIsGeneratingScript(true);
    try {
      const res = await fetch('/api/gemini/call-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead }),
      });
      const data = await res.json();
      if (data.success && data.script) {
        setAiScript(data.script);
      }
    } catch (err) {
      console.error('Failed to generate call script:', err);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle || !newTaskDate) return;
    onAddTask({
      leadId: lead.id,
      title: newTaskTitle,
      dueDate: newTaskDate,
      assignedTo: lead.assignedTo,
      completed: false,
      type: 'followup',
    });
    setNewTaskTitle('');
    setNewTaskDate('');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const currentResearch = lead.companyResearch;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-end p-0 sm:p-4 overflow-y-auto">
      <div className="bg-[#18181b] border border-[#27272a] w-full max-w-4xl h-full sm:h-auto sm:max-h-[94vh] sm:rounded-2xl shadow-2xl flex flex-col overflow-hidden text-zinc-100">
        {/* Modal Header */}
        <div className="bg-[#09090b] p-4 border-b border-[#27272a] flex items-start justify-between">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-bold text-zinc-100">{lead.name}</h2>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 font-bold border border-emerald-500/20">
                {lead.company}
              </span>
              {lead.prospectType && (
                <span className="text-[10px] px-2 py-0.5 rounded uppercase font-bold bg-[#18181b] text-zinc-400 border border-[#27272a]">
                  {lead.prospectType}
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400 mt-0.5 flex items-center gap-2">
              <span>{lead.role || 'Contact'}</span>
              <span>•</span>
              <span className="text-emerald-400 font-mono font-semibold">
                ${(lead.value || 0).toLocaleString()}
              </span>
              <span>•</span>
              <span>Assigned: {lead.assignedTo}</span>
              {lead.fundingInfo && (
                <>
                  <span>•</span>
                  <span className="text-amber-400 font-medium">{lead.fundingInfo}</span>
                </>
              )}
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onOpenCallLogModal(lead)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-black rounded-lg shadow-sm transition"
            >
              <PhoneCall className="w-3.5 h-3.5 text-black" /> Call & Log Activity
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Lead Details Banner */}
        <div className="bg-[#09090b] p-3 px-5 border-b border-[#27272a] grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          <div>
            <span className="text-zinc-500 text-[10px] uppercase font-bold">Direct Phone</span>
            <div className="text-zinc-200 font-mono font-medium flex items-center gap-1">
              {lead.phone}
              {lead.phoneLookupStatus === 'verified' && (
                <Check className="w-3 h-3 text-emerald-400" />
              )}
            </div>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] uppercase font-bold">Email</span>
            <div className="text-zinc-200 truncate">{lead.email}</div>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] uppercase font-bold">Cadence Step</span>
            <div className="text-emerald-400 font-bold">Step {lead.cadenceStep || 1} of 5</div>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] uppercase font-bold">Source</span>
            <div className="text-zinc-200 font-medium">{lead.source}</div>
          </div>
          <div>
            <span className="text-zinc-500 text-[10px] uppercase font-bold">Stage</span>
            <select
              value={lead.stage}
              onChange={(e) => onUpdateLeadStage(lead.id, e.target.value as PipelineStage)}
              className="bg-[#18181b] text-zinc-200 text-xs rounded border border-[#27272a] px-1.5 py-0.5"
            >
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="qualifying">Qualifying</option>
              <option value="proposal_sent">Proposal Sent</option>
              <option value="negotiation">Negotiation</option>
              <option value="won">Closed Won</option>
              <option value="lost">Closed Lost</option>
            </select>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#27272a] bg-[#18181b] px-4 text-xs font-semibold space-x-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('research')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'research'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Newspaper className="w-3.5 h-3.5 text-emerald-400" /> Research & Press Releases
          </button>
          <button
            onClick={() => setActiveTab('selling_angles')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'selling_angles'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" /> Selling Angles & AI Score
          </button>
          <button
            onClick={() => setActiveTab('ai_email')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'ai_email'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Send className="w-3.5 h-3.5 text-emerald-400" /> Styled AI Email
          </button>
          <button
            onClick={() => setActiveTab('ai_script')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'ai_script'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <PhoneCall className="w-3.5 h-3.5 text-emerald-400" /> Talk Track
          </button>
          <button
            onClick={() => setActiveTab('timeline')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'timeline'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" /> Call Logs ({leadActivities.length})
          </button>
          <button
            onClick={() => setActiveTab('tasks')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition ${
              activeTab === 'tasks'
                ? 'border-emerald-400 text-emerald-400 font-bold'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" /> Reminders ({leadTasks.length})
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
          {/* TAB 1: RESEARCH & PRESS RELEASES */}
          {activeTab === 'research' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-[#09090b] p-4 rounded-xl border border-[#27272a]">
                <div>
                  <h4 className="font-bold text-zinc-100 flex items-center gap-2 text-sm">
                    <Newspaper className="w-4 h-4 text-emerald-400" /> Corporate Press Release & Funding Audit
                  </h4>
                  <p className="text-zinc-400 text-[11px] mt-0.5">
                    Source-grounded intelligence for {lead.company}.
                  </p>
                </div>
                <button
                  onClick={handleRunResearch}
                  disabled={isResearching}
                  className="px-4 py-2 bg-white hover:bg-zinc-200 text-black font-bold rounded-lg transition shadow-sm flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 text-emerald-500" />
                  {isResearching ? 'Auditing Company...' : 'Run Live Research'}
                </button>
              </div>

              {currentResearch ? (
                <div className="space-y-4">
                  {/* Latest Press Releases */}
                  <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] space-y-3">
                    <span className="font-bold text-zinc-200 block text-xs">
                      Latest Discoverable Press Releases
                    </span>
                    <div className="space-y-2">
                      {currentResearch.latestPressReleases?.map((pr, i) => (
                        <div key={i} className="p-3 bg-[#18181b] rounded-lg border border-[#27272a] space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-zinc-100">{pr.title}</span>
                            <span className="text-[10px] text-zinc-500">{pr.date}</span>
                          </div>
                          <p className="text-zinc-400 text-[11px]">{pr.summary}</p>
                          <div className="text-emerald-400 text-[11px] font-medium pt-1">
                            Sales Hook: {pr.strategicAngle}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Provider Classification */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] space-y-2">
                      <span className="font-bold text-zinc-200 block text-xs">Provider Classification</span>
                      {currentResearch.providerClassification?.map((p, idx) => (
                        <div key={idx} className="flex items-center justify-between text-[11px]">
                          <span className="text-zinc-400">{p.category}:</span>
                          <span className="font-semibold text-zinc-200">{p.provider}</span>
                        </div>
                      ))}
                    </div>

                    <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] space-y-2">
                      <span className="font-bold text-zinc-200 block text-xs">Phone Dialer Status</span>
                      {currentResearch.phoneLookupResult && (
                        <div className="space-y-1">
                          <div className="text-emerald-400 font-mono font-bold text-sm">
                            {currentResearch.phoneLookupResult.number}
                          </div>
                          <div className="text-zinc-400 text-[11px]">
                            {currentResearch.phoneLookupResult.confidence}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-8 bg-[#09090b] border border-[#27272a] rounded-xl text-center text-zinc-400">
                  No press release research data generated yet. Click "Run Live Research" above.
                </div>
              )}
            </div>
          )}

          {/* TAB 2: SELLING ANGLES & AI SCORE */}
          {activeTab === 'selling_angles' && (
            <div className="space-y-4">
              <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] flex items-center justify-between">
                <div>
                  <span className="text-zinc-400 font-semibold block text-xs">Gemini AI Qualification Score</span>
                  <div className="text-2xl font-extrabold text-amber-400 mt-1">
                    {lead.aiScore || 88}/100 ({lead.aiIntent || 'Hot'} Intent)
                  </div>
                </div>
                <button
                  onClick={handleScoreLead}
                  disabled={isScoring}
                  className="px-4 py-2 bg-white hover:bg-zinc-200 text-black font-bold rounded-lg shadow-sm transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 text-emerald-500" />
                  {isScoring ? 'Scoring...' : 'Re-Score Lead'}
                </button>
              </div>

              {lead.sellingAngles && lead.sellingAngles.length > 0 && (
                <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] space-y-3">
                  <span className="font-bold text-zinc-100 block text-xs">Tailored Selling Angles</span>
                  <div className="space-y-2">
                    {lead.sellingAngles.map((angle) => (
                      <div key={angle.id} className="p-3 bg-[#18181b] rounded-lg border border-[#27272a] space-y-1">
                        <span className="font-bold text-emerald-400">{angle.title}</span>
                        <p className="text-zinc-300 italic text-[11px]">"{angle.hook}"</p>
                        <p className="text-zinc-400 text-[11px]">{angle.valueProp}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {lead.nextBestAction && (
                <div className="p-4 bg-emerald-950/20 border border-emerald-500/30 rounded-xl space-y-1 text-xs">
                  <span className="text-emerald-400 font-bold block">Next Best Action Recommendation:</span>
                  <p className="font-semibold text-zinc-100">{lead.nextBestAction.title}</p>
                  <p className="text-zinc-400 text-[11px]">{lead.nextBestAction.reasoning}</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: STYLED AI EMAIL */}
          {activeTab === 'ai_email' && (
            <div className="space-y-4">
              <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-zinc-400 block mb-1 font-semibold">Select Style Preset</label>
                    <select
                      value={selectedStyleName}
                      onChange={(e) => setSelectedStyleName(e.target.value)}
                      className="w-full bg-[#18181b] border border-[#27272a] rounded-lg p-2 text-zinc-200 focus:outline-none font-semibold"
                    >
                      {styles.map((s) => (
                        <option key={s.id} value={s.name}>
                          {s.name} ({s.tone})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-zinc-400 block mb-1 font-semibold">Outreach Objective</label>
                    <input
                      type="text"
                      value={emailObjective}
                      onChange={(e) => setEmailObjective(e.target.value)}
                      className="w-full bg-[#18181b] border border-[#27272a] rounded-lg p-2 text-zinc-200 focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  onClick={handleGenerateEmail}
                  disabled={isGeneratingEmail}
                  className="px-4 py-2 bg-white hover:bg-zinc-200 text-black font-semibold rounded-lg shadow-sm transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 text-emerald-500" />
                  {isGeneratingEmail ? 'Drafting Styled Email...' : 'Generate Email with Selected Style'}
                </button>
              </div>

              {aiEmail && (
                <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] space-y-3">
                  <div className="flex items-center justify-between border-b border-[#27272a] pb-2">
                    <span className="font-bold text-zinc-200">Email Draft ({selectedStyleName})</span>
                    <button
                      onClick={() => copyToClipboard(`Subject: ${aiEmail.subject}\n\n${aiEmail.body}`)}
                      className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-medium"
                    >
                      {copiedEmail ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedEmail ? 'Copied!' : 'Copy Email'}
                    </button>
                  </div>

                  <div>
                    <span className="text-zinc-500 font-semibold block text-[10px]">SUBJECT:</span>
                    <div className="font-bold text-emerald-400 text-xs mt-0.5">{aiEmail.subject}</div>
                  </div>

                  <div>
                    <span className="text-zinc-500 font-semibold block text-[10px]">BODY:</span>
                    <pre className="whitespace-pre-wrap text-zinc-300 font-sans leading-relaxed mt-1 bg-[#18181b] p-3 rounded-lg border border-[#27272a] text-xs">
                      {aiEmail.body}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: TALK TRACK */}
          {activeTab === 'ai_script' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-[#09090b] p-4 rounded-xl border border-[#27272a]">
                <div>
                  <h4 className="font-bold text-zinc-200">Telecalling Talk Track & Pitch Guide</h4>
                  <p className="text-zinc-400 text-[11px]">
                    Tailored for calling {lead.name} at {lead.company}.
                  </p>
                </div>
                <button
                  onClick={handleGenerateScript}
                  disabled={isGeneratingScript}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-lg shadow-sm transition flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 text-black" />
                  {isGeneratingScript ? 'Writing Script...' : 'Generate Talk Track'}
                </button>
              </div>

              {aiScript && (
                <div className="space-y-3">
                  <div className="p-3 bg-[#09090b] rounded-xl border border-[#27272a] space-y-1">
                    <span className="text-emerald-400 font-bold">1. Call Opener</span>
                    <p className="text-zinc-200 italic">"{aiScript.openingLine}"</p>
                  </div>

                  <div className="p-3 bg-[#09090b] rounded-xl border border-[#27272a] space-y-1">
                    <span className="text-emerald-400 font-bold">2. Key Pitch Points</span>
                    <ul className="list-disc list-inside space-y-1 text-zinc-300">
                      {aiScript.keyPitchPoints.map((pt, i) => (
                        <li key={i}>{pt}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-3 bg-[#09090b] rounded-xl border border-[#27272a] space-y-2">
                    <span className="text-amber-400 font-bold">3. Objection Responses</span>
                    <div className="space-y-2">
                      {aiScript.objectionHandling.map((item, i) => (
                        <div key={i} className="p-2 bg-[#18181b] rounded border border-[#27272a] space-y-0.5">
                          <div className="text-rose-300 font-semibold">Objection: "{item.objection}"</div>
                          <div className="text-zinc-300">Response: "{item.response}"</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: TIMELINE */}
          {activeTab === 'timeline' && (
            <div className="space-y-3">
              {leadActivities.length === 0 ? (
                <div className="p-8 text-center text-zinc-500">
                  No call or activity logs recorded for this lead yet.
                </div>
              ) : (
                leadActivities.map((act) => (
                  <div key={act.id} className="p-3 bg-[#09090b] rounded-xl border border-[#27272a] space-y-1">
                    <div className="flex items-center justify-between font-semibold text-zinc-200">
                      <span>{act.title}</span>
                      <span className="text-[10px] text-zinc-400">
                        {new Date(act.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-zinc-300">{act.description}</p>
                    {act.outcome && (
                      <div className="text-[11px] text-emerald-400 font-medium">
                        Outcome: {act.outcome}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 6: TASKS */}
          {activeTab === 'tasks' && (
            <div className="space-y-4">
              <form onSubmit={handleCreateTask} className="flex gap-2 text-xs">
                <input
                  type="text"
                  placeholder="Schedule a follow-up task..."
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  className="flex-1 bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
                />
                <input
                  type="date"
                  value={newTaskDate}
                  onChange={(e) => setNewTaskDate(e.target.value)}
                  className="bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-3 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold rounded-lg"
                >
                  Add Task
                </button>
              </form>

              <div className="space-y-2">
                {leadTasks.length === 0 ? (
                  <div className="p-6 text-center text-zinc-500">No scheduled tasks for this lead.</div>
                ) : (
                  leadTasks.map((t) => (
                    <div
                      key={t.id}
                      className="p-2.5 bg-[#09090b] rounded-xl border border-[#27272a] flex items-center justify-between text-xs"
                    >
                      <span className="font-semibold text-zinc-200">{t.title}</span>
                      <span className="text-zinc-400 font-mono">Due: {t.dueDate}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
