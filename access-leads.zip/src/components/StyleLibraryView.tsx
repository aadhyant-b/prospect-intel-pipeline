import React, { useState } from 'react';
import {
  Sparkles,
  BookOpen,
  Plus,
  Edit2,
  CheckCircle2,
  Copy,
  Mail,
  Zap,
  Sliders,
} from 'lucide-react';
import { StylePreset, Lead } from '../types';

interface StyleLibraryViewProps {
  styles: StylePreset[];
  leads: Lead[];
  onAddStyle: (style: StylePreset) => void;
  onOpenLeadDetail: (lead: Lead) => void;
}

export const StyleLibraryView: React.FC<StyleLibraryViewProps> = ({
  styles,
  leads,
  onAddStyle,
  onOpenLeadDetail,
}) => {
  const [selectedStyleId, setSelectedStyleId] = useState<string>(styles[0]?.id || '');
  const [previewLeadId, setPreviewLeadId] = useState<string>(leads[0]?.id || '');
  const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);
  const [generatedDraft, setGeneratedDraft] = useState<{ subject: string; body: string } | null>(null);

  // New Style Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newTone, setNewTone] = useState('');
  const [newInstructions, setNewInstructions] = useState('');

  const activeStyle = styles.find((s) => s.id === selectedStyleId) || styles[0];
  const activeLead = leads.find((l) => l.id === previewLeadId) || leads[0];

  const handleTestStyle = async () => {
    if (!activeStyle || !activeLead) return;

    setIsGeneratingPreview(true);

    try {
      const res = await fetch('/api/gemini/generate-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lead: activeLead,
          styleName: activeStyle.name,
          styleInstructions: activeStyle.promptInstructions,
          tone: activeStyle.tone,
        }),
      });

      const data = await res.json();
      if (data.success && data.email) {
        setGeneratedDraft(data.email);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingPreview(false);
    }
  };

  const handleCreateStyle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName) return;

    const newStyle: StylePreset = {
      id: `style_${Date.now()}`,
      name: newName,
      description: newDesc || 'Custom sales copywriting style preset.',
      tone: newTone || 'Professional',
      promptInstructions: newInstructions || 'Keep email high-impact and clear.',
    };

    onAddStyle(newStyle);
    setSelectedStyleId(newStyle.id);
    setShowAddModal(false);
    setNewName('');
    setNewDesc('');
    setNewTone('');
    setNewInstructions('');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <BookOpen className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-zinc-100">
              Outreach Copywriting Style Library & System Prompts
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Configure tailored messaging personalities ranging from Concise C-Level to Challenger Press-Release angles.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl shadow-sm transition flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" /> Create Custom Style Preset
        </button>
      </div>

      {/* Style Library Grid & Live Preview Tester */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Style Presets List */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400 px-1">
            Available Style Presets ({styles.length})
          </h3>

          {styles.map((style) => {
            const isSelected = style.id === selectedStyleId;
            return (
              <div
                key={style.id}
                onClick={() => {
                  setSelectedStyleId(style.id);
                  setGeneratedDraft(null);
                }}
                className={`p-4 rounded-xl border cursor-pointer transition text-xs space-y-2 ${
                  isSelected
                    ? 'bg-[#27272a] border-emerald-500 text-white shadow-md'
                    : 'bg-[#18181b] border-[#27272a] text-zinc-300 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-zinc-100">{style.name}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 font-semibold border border-emerald-500/20">
                    {style.tone}
                  </span>
                </div>
                <p className="text-zinc-400 text-[11px] leading-relaxed">{style.description}</p>
              </div>
            );
          })}
        </div>

        {/* Live Preview Tester */}
        <div className="lg:col-span-2 bg-[#18181b] border border-[#27272a] p-6 rounded-2xl space-y-5">
          {activeStyle ? (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#27272a]">
                <div>
                  <h3 className="text-base font-bold text-zinc-100 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" /> Test Style: {activeStyle.name}
                  </h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Select a prospect to generate an instant email draft using this style.
                  </p>
                </div>

                {/* Target Lead Selector */}
                <select
                  value={previewLeadId}
                  onChange={(e) => setPreviewLeadId(e.target.value)}
                  className="bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none"
                >
                  {leads.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.company})
                    </option>
                  ))}
                </select>
              </div>

              {/* Instructions Box */}
              <div className="bg-[#09090b] p-4 rounded-xl border border-[#27272a] text-xs space-y-1">
                <span className="text-zinc-500 font-semibold uppercase text-[10px]">
                  System Prompt Guidelines:
                </span>
                <p className="text-zinc-200 font-mono text-[11px] leading-relaxed">
                  {activeStyle.promptInstructions}
                </p>
              </div>

              {/* Action Button */}
              <button
                onClick={handleTestStyle}
                disabled={isGeneratingPreview}
                className="w-full py-2.5 bg-white hover:bg-zinc-200 text-black font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                <Zap className="w-4 h-4 text-emerald-500" />
                {isGeneratingPreview ? 'Generating AI Email Draft...' : `Generate Test Email for ${activeLead?.name || 'Prospect'}`}
              </button>

              {/* Draft Output */}
              {generatedDraft && (
                <div className="bg-[#09090b] border border-[#27272a] p-4 rounded-xl space-y-3 text-xs">
                  <div>
                    <span className="text-zinc-500 font-semibold block text-[10px]">SUBJECT:</span>
                    <span className="font-bold text-emerald-400 text-sm">{generatedDraft.subject}</span>
                  </div>

                  <div>
                    <span className="text-zinc-500 font-semibold block text-[10px] mb-1">EMAIL BODY:</span>
                    <p className="text-zinc-200 whitespace-pre-wrap font-mono text-[11px] leading-relaxed bg-[#18181b] p-3 rounded-lg border border-[#27272a]">
                      {generatedDraft.body}
                    </p>
                  </div>

                  <div className="flex justify-end space-x-2 pt-2 border-t border-[#27272a]">
                    <button
                      onClick={() => navigator.clipboard.writeText(`Subject: ${generatedDraft.subject}\n\n${generatedDraft.body}`)}
                      className="px-3 py-1.5 bg-[#18181b] hover:bg-[#27272a] text-zinc-300 rounded-lg flex items-center gap-1 font-semibold"
                    >
                      <Copy className="w-3.5 h-3.5 text-emerald-400" /> Copy Text
                    </button>
                    {activeLead && (
                      <button
                        onClick={() => onOpenLeadDetail(activeLead)}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-lg flex items-center gap-1"
                      >
                        <Mail className="w-3.5 h-3.5" /> Open Lead Workspace
                      </button>
                    )}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-12 text-zinc-500 text-xs">Select a style preset from the left list.</div>
          )}
        </div>
      </div>

      {/* CREATE STYLE MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#18181b] border border-[#27272a] w-full max-w-md rounded-2xl p-6 space-y-4 text-xs text-zinc-100">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-400" /> Add Copywriting Style Preset
            </h3>

            <form onSubmit={handleCreateStyle} className="space-y-3">
              <div>
                <label className="text-zinc-300 font-semibold block mb-1">Style Name *</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Challenger Tech Transition"
                  className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-zinc-300 font-semibold block mb-1">Tone Label</label>
                <input
                  type="text"
                  value={newTone}
                  onChange={(e) => setNewTone(e.target.value)}
                  placeholder="e.g. Provocative & Data-Driven"
                  className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-zinc-300 font-semibold block mb-1">Description</label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Brief description of when to use this style..."
                  className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-zinc-300 font-semibold block mb-1">System Prompt Instructions</label>
                <textarea
                  rows={4}
                  required
                  value={newInstructions}
                  onChange={(e) => setNewInstructions(e.target.value)}
                  placeholder="Instructions for Gemini AI when drafting with this style..."
                  className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-xl p-2.5 focus:outline-none font-mono text-[11px]"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-[#27272a]">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#09090b] hover:bg-zinc-800 text-zinc-300 border border-[#27272a] rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl"
                >
                  Save Preset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
