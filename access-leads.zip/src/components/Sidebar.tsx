import React from 'react';
import {
  LayoutDashboard,
  Users,
  Kanban,
  Headphones,
  BarChart3,
  ShieldCheck,
  Zap,
  Copy,
  Clock,
  Newspaper,
  BookOpen,
  Archive,
} from 'lucide-react';
import { Role } from '../types';

export type TabType =
  | 'dashboard'
  | 'salesforce_import'
  | 'followups'
  | 'research_hub'
  | 'leads'
  | 'kanban'
  | 'telecaller'
  | 'style_library'
  | 'archive'
  | 'analytics'
  | 'team';

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  role: Role;
  pendingCallbacksCount: number;
  dueTasksCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  role,
  pendingCallbacksCount,
  dueTasksCount = 0,
}) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null,
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'salesforce_import',
      label: 'Salesforce & Import',
      icon: Copy,
      badge: 'AI Parse',
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'followups',
      label: 'Follow-Ups & Cadence',
      icon: Clock,
      badge: dueTasksCount > 0 ? dueTasksCount : null,
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'research_hub',
      label: 'Corporate Research Hub',
      icon: Newspaper,
      badge: null,
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'leads',
      label: 'All Pursuits & Leads',
      icon: Users,
      badge: null,
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'kanban',
      label: 'Pipeline Board',
      icon: Kanban,
      badge: null,
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'telecaller',
      label: 'Telecalling Queue',
      icon: Headphones,
      badge: pendingCallbacksCount > 0 ? pendingCallbacksCount : null,
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'style_library',
      label: 'Outreach Style Library',
      icon: BookOpen,
      badge: null,
      allowedRoles: ['admin', 'manager'],
    },
    {
      id: 'archive',
      label: 'Meetings & Archive',
      icon: Archive,
      badge: null,
      allowedRoles: ['admin', 'manager', 'telecaller'],
    },
    {
      id: 'analytics',
      label: 'Sales Analytics',
      icon: BarChart3,
      badge: null,
      allowedRoles: ['admin', 'manager'],
    },
    {
      id: 'team',
      label: 'Access & Team',
      icon: ShieldCheck,
      badge: null,
      allowedRoles: ['admin', 'manager'],
    },
  ];

  return (
    <aside className="w-full md:w-60 bg-[#09090b] border-r border-[#27272a] flex-shrink-0 p-3 flex flex-row md:flex-col justify-between">
      <div className="flex flex-row md:flex-col space-x-1 md:space-x-0 md:space-y-1 w-full overflow-x-auto md:overflow-visible">
        <div className="hidden md:block text-[10px] font-semibold text-zinc-500 uppercase tracking-wider px-3 pt-2 pb-1">
          Pursuit Navigation
        </div>

        {navItems
          .filter((item) => item.allowedRoles.includes(role))
          .map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id as TabType)}
                className={`flex items-center space-x-2.5 px-3 py-2.5 rounded-lg text-xs font-medium transition w-full whitespace-nowrap ${
                  isActive
                    ? 'bg-[#27272a] text-white shadow-sm font-semibold'
                    : 'text-zinc-400 hover:text-zinc-100 hover:bg-[#18181b]'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-zinc-400'}`} />
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge !== null && (
                  <span
                    className={`px-1.5 py-0.5 text-[10px] rounded-full font-bold ${
                      isActive
                        ? 'bg-emerald-500 text-black'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
      </div>

      {/* AI Pursuit Banner in Sidebar */}
      <div className="hidden md:block mt-6 p-3 rounded-xl bg-[#18181b] border border-[#27272a] text-xs">
        <div className="flex items-center space-x-2 text-emerald-400 font-semibold mb-1">
          <Zap className="w-3.5 h-3.5 text-emerald-400" />
          <span>Pursuit Intelligence</span>
        </div>
        <p className="text-[11px] text-zinc-400 leading-relaxed">
          Gemini 3.6 Flash powers real-time press discovery, phone verification, and selling angles.
        </p>
      </div>
    </aside>
  );
};
