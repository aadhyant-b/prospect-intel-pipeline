import React, { useState } from 'react';
import {
  PhoneCall,
  PhoneForwarded,
  Sparkles,
  CheckCircle,
  Clock,
  User,
  Building,
  Mail,
  MapPin,
  Calendar,
  FileText,
  Flame,
  ChevronRight,
  ChevronLeft,
  MessageSquare,
  AlertCircle,
  PhoneOff,
} from 'lucide-react';
import { Lead, Activity, CallOutcome, AICallScript } from '../types';

interface TelecallerQueueProps {
  leads: Lead[];
  activities: Activity[];
  onLogCall: (
    leadId: string,
    outcome: CallOutcome,
    notes: string,
    durationSeconds: number,
    nextFollowUpDate?: string
  ) => void;
  onSelectLead: (lead: Lead) => void;
}

export const TelecallerQueue: React.FC<TelecallerQueueProps> = ({
  leads,
  activities,
  onLogCall,
  onSelectLead,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [callOutcome, setCallOutcome] = useState<CallOutcome>('Connected - Interested');
  const [callNotes, setCallNotes] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(3);
  const [nextFollowUpDate, setNextFollowUpDate] = useState('');
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [aiScript, setAiScript] = useState<AICallScript | null>(null);

  const activeLeads = leads.filter((l) => l.stage !== 'won' && l.stage !== 'lost');
  const currentLead = activeLeads[currentIndex] || activeLeads[0];

  const handleNextLead = () => {
    if (currentIndex < activeLeads.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setCallNotes('');
      setAiScript(null);
    }
  };

  const handlePrevLead = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setCallNotes('');
      setAiScript(null);
    }
  };

  const handleSaveCallAndNext = () => {
    if (!currentLead) return;
    onLogCall(
      currentLead.id,
      callOutcome,
      callNotes,
      durationMinutes * 60,
      nextFollowUpDate || undefined
    );
    setCallNotes('');
    setNextFollowUpDate('');
    setAiScript(null);
    if (currentIndex < activeLeads.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const fetchAiScript = async () => {
    if (!currentLead) return;
    setIsGeneratingScript(true);
    try {
      const res = await fetch('/api/gemini/call-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead: currentLead }),
      });
      const data = await res.json();
      if (data.success && data.script) {
        setAiScript(data.script);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingScript(false);
    }
  };

  if (!currentLead) {
    return (
      <div className="p-8 text-center text-slate-400">
        No active leads available in the telecalling queue.
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Telecalling Workstation Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-[#18181b] p-4 rounded-2xl border border-[#27272a]">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <PhoneCall className="w-4 h-4" />
            </span>
            <h1 className="text-lg font-bold text-zinc-100">
              Telecalling Workstation Mode
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Step through active contacts, generate call talk tracks, and log activity.
          </p>
        </div>

        {/* Counter & Queue Navigation */}
        <div className="flex items-center space-x-3 text-xs">
          <span className="text-zinc-400 font-medium">
            Queue Item <strong>{currentIndex + 1}</strong> of {activeLeads.length}
          </span>
          <div className="flex items-center space-x-1">
            <button
              onClick={handlePrevLead}
              disabled={currentIndex === 0}
              className="p-1.5 rounded-lg bg-[#09090b] hover:bg-zinc-800 disabled:opacity-40 text-zinc-200 border border-[#27272a] transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextLead}
              disabled={currentIndex === activeLeads.length - 1}
              className="p-1.5 rounded-lg bg-[#09090b] hover:bg-zinc-800 disabled:opacity-40 text-zinc-200 border border-[#27272a] transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Split Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Lead Info & Contact Card (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl shadow-sm space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  {currentLead.source} Lead
                </span>
                <h2 className="text-lg font-bold text-zinc-100 mt-1">
                  {currentLead.name}
                </h2>
                <p className="text-xs text-zinc-400 flex items-center gap-1">
                  <Building className="w-3.5 h-3.5 text-zinc-500" />
                  {currentLead.company} {currentLead.role ? `• ${currentLead.role}` : ''}
                </p>
              </div>

              {currentLead.aiScore && (
                <div className="text-center px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300">
                  <div className="text-xs font-bold flex items-center gap-1">
                    <Flame className="w-3 h-3 text-amber-400" /> {currentLead.aiScore}
                  </div>
                  <div className="text-[9px] uppercase font-semibold">AI Intent</div>
                </div>
              )}
            </div>

            {/* Direct Contact Links */}
            <div className="p-3 bg-[#09090b] rounded-xl border border-[#27272a] space-y-2 text-xs">
              <div className="flex items-center justify-between text-zinc-200">
                <span className="flex items-center gap-2">
                  <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                  <strong className="font-mono text-emerald-400">{currentLead.phone}</strong>
                </span>
                <a
                  href={`tel:${currentLead.phone}`}
                  className="px-2.5 py-1 text-[11px] font-semibold bg-emerald-500 hover:bg-emerald-400 text-black rounded transition"
                >
                  Dial Now
                </a>
              </div>
              <div className="flex items-center justify-between text-zinc-200">
                <span className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-zinc-400" />
                  <span className="truncate max-w-[180px] text-zinc-300">{currentLead.email}</span>
                </span>
                <a
                  href={`mailto:${currentLead.email}`}
                  className="px-2.5 py-1 text-[11px] bg-[#18181b] hover:bg-zinc-800 text-zinc-200 border border-[#27272a] rounded transition"
                >
                  Email
                </a>
              </div>
            </div>

            {/* Financial & Priority Meta */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-[#09090b] p-2.5 rounded-lg border border-[#27272a]">
                <span className="text-zinc-400 text-[10px]">Estimated Deal Value</span>
                <div className="font-bold text-zinc-200 text-sm">
                  ${(currentLead.value || 0).toLocaleString()}
                </div>
              </div>
              <div className="bg-[#09090b] p-2.5 rounded-lg border border-[#27272a]">
                <span className="text-zinc-400 text-[10px]">Stage</span>
                <div className="font-semibold text-emerald-400 capitalize text-sm">
                  {currentLead.stage.replace('_', ' ')}
                </div>
              </div>
            </div>

            {/* Notes */}
            <div className="space-y-1 text-xs">
              <span className="text-zinc-400 font-semibold flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-zinc-500" /> Account Background Notes
              </span>
              <p className="bg-[#09090b] p-2.5 rounded-lg text-zinc-300 leading-relaxed border border-[#27272a]">
                {currentLead.notes || 'No prior notes logged.'}
              </p>
            </div>

            <button
              onClick={() => onSelectLead(currentLead)}
              className="w-full py-2 text-xs font-semibold bg-[#09090b] hover:bg-zinc-800 text-zinc-200 border border-[#27272a] rounded-lg transition text-center"
            >
              Open Full Lead Profile & History &rarr;
            </button>
          </div>

          {/* AI Talk Track Request Button */}
          <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                Gemini Telecall Pitch & Script
              </span>
              <button
                onClick={fetchAiScript}
                disabled={isGeneratingScript}
                className="px-3 py-1.5 text-xs font-semibold bg-white hover:bg-zinc-200 text-black rounded-lg transition disabled:opacity-50"
              >
                {isGeneratingScript ? 'Generating Script...' : 'Generate Pitch Script'}
              </button>
            </div>

            {aiScript && (
              <div className="p-3 bg-[#09090b] rounded-xl border border-[#27272a] text-xs space-y-2.5">
                <div>
                  <span className="text-emerald-400 font-bold">Recommended Opener:</span>
                  <p className="text-zinc-200 italic mt-0.5">"{aiScript.openingLine}"</p>
                </div>
                <div>
                  <span className="text-emerald-400 font-bold">Key Pitch Points:</span>
                  <ul className="list-disc list-inside text-zinc-300 mt-0.5 space-y-0.5">
                    {aiScript.keyPitchPoints.map((pt, i) => (
                      <li key={i}>{pt}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <span className="text-amber-400 font-bold">Closing Question:</span>
                  <p className="text-zinc-200 font-medium mt-0.5">"{aiScript.closingQuestion}"</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Call Logging Form (7 cols) */}
        <div className="lg:col-span-7 bg-[#18181b] border border-[#27272a] p-5 rounded-2xl shadow-sm space-y-5">
          <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2 border-b border-[#27272a] pb-3">
            <PhoneForwarded className="w-4 h-4 text-emerald-400" />
            Log Call Activity & Next Steps
          </h3>

          {/* Outcome Radio Buttons */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 block">
              Call Outcome
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {[
                'Connected - Interested',
                'Connected - Callback Requested',
                'Connected - Not Interested',
                'Left Voicemail',
                'No Answer / Busy',
                'Wrong Number',
              ].map((outcome) => (
                <button
                  key={outcome}
                  type="button"
                  onClick={() => setCallOutcome(outcome as CallOutcome)}
                  className={`p-2.5 rounded-xl text-left border transition font-medium flex items-center justify-between ${
                    callOutcome === outcome
                      ? 'bg-emerald-500 text-black border-emerald-400 shadow-sm font-bold'
                      : 'bg-[#09090b] text-zinc-300 border-[#27272a] hover:bg-zinc-800'
                  }`}
                >
                  <span>{outcome}</span>
                  {callOutcome === outcome && <CheckCircle className="w-3.5 h-3.5 text-black" />}
                </button>
              ))}
            </div>
          </div>

          {/* Call Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1">
              <label className="text-zinc-300 font-medium">Duration (Minutes)</label>
              <input
                type="number"
                min="1"
                max="120"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-zinc-300 font-medium">
                Schedule Callback Date (Optional)
              </label>
              <input
                type="date"
                value={nextFollowUpDate}
                onChange={(e) => setNextFollowUpDate(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1 text-xs">
            <label className="text-zinc-300 font-medium">Call Summary & Key Takeaways</label>
            <textarea
              rows={4}
              placeholder="e.g. Discussed pricing tiers. Prospect asked for enterprise compliance document and agreed to follow-up meeting on Friday."
              value={callNotes}
              onChange={(e) => setCallNotes(e.target.value)}
              className="w-full bg-[#09090b] text-zinc-100 placeholder-zinc-500 border border-[#27272a] rounded-xl p-3 focus:outline-none focus:border-zinc-500"
            />
          </div>

          {/* Submit Action */}
          <div className="pt-2 flex items-center justify-between border-t border-[#27272a]">
            <button
              onClick={handleNextLead}
              className="px-4 py-2.5 text-xs text-zinc-400 hover:text-white transition"
            >
              Skip to Next Lead
            </button>
            <button
              onClick={handleSaveCallAndNext}
              className="px-5 py-2.5 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl shadow-sm transition flex items-center gap-1.5"
            >
              <CheckCircle className="w-4 h-4" /> Save Call Log & Proceed Next &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
