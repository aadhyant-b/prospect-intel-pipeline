import React from 'react';
import {
  Users,
  DollarSign,
  TrendingUp,
  PhoneCall,
  Sparkles,
  ArrowUpRight,
  Flame,
  Clock,
  CheckCircle2,
  Calendar,
  Building,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { Lead, Activity, Task } from '../types';

interface DashboardViewProps {
  leads: Lead[];
  activities: Activity[];
  tasks: Task[];
  onSelectLead: (lead: Lead) => void;
  onNavigateToTab: (tab: any) => void;
}

const STAGE_COLORS: Record<string, string> = {
  new: '#3b82f6',
  contacted: '#06b6d4',
  qualifying: '#8b5cf6',
  proposal_sent: '#ec4899',
  negotiation: '#f59e0b',
  won: '#10b981',
  lost: '#ef4444',
};

const SOURCE_COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4'];

export const DashboardView: React.FC<DashboardViewProps> = ({
  leads,
  activities,
  tasks,
  onSelectLead,
  onNavigateToTab,
}) => {
  const totalLeads = leads.length;
  const totalPipelineValue = leads
    .filter((l) => l.stage !== 'lost')
    .reduce((sum, l) => sum + (l.value || 0), 0);

  const wonLeads = leads.filter((l) => l.stage === 'won');
  const wonValue = wonLeads.reduce((sum, l) => sum + (l.value || 0), 0);
  const conversionRate = totalLeads > 0 ? Math.round((wonLeads.length / totalLeads) * 100) : 0;

  const hotLeads = leads.filter((l) => l.aiIntent === 'Hot' || (l.aiScore && l.aiScore >= 80));
  const callsToday = activities.filter((a) => a.type === 'call').length;

  // Pipeline stage chart data
  const stageCounts: Record<string, number> = {
    new: 0,
    contacted: 0,
    qualifying: 0,
    proposal_sent: 0,
    negotiation: 0,
    won: 0,
    lost: 0,
  };

  leads.forEach((l) => {
    if (stageCounts[l.stage] !== undefined) {
      stageCounts[l.stage] += 1;
    }
  });

  const stageChartData = [
    { name: 'New Lead', count: stageCounts.new, key: 'new' },
    { name: 'Contacted', count: stageCounts.contacted, key: 'contacted' },
    { name: 'Qualifying', count: stageCounts.qualifying, key: 'qualifying' },
    { name: 'Proposal', count: stageCounts.proposal_sent, key: 'proposal_sent' },
    { name: 'Negotiation', count: stageCounts.negotiation, key: 'negotiation' },
    { name: 'Won', count: stageCounts.won, key: 'won' },
    { name: 'Lost', count: stageCounts.lost, key: 'lost' },
  ];

  // Source chart data
  const sourceMap: Record<string, number> = {};
  leads.forEach((l) => {
    sourceMap[l.source] = (sourceMap[l.source] || 0) + 1;
  });
  const sourceChartData = Object.keys(sourceMap).map((key) => ({
    name: key,
    value: sourceMap[key],
  }));

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner & Welcome */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#18181b] p-5 rounded-2xl border border-[#27272a] shadow-sm">
        <div>
          <h1 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
            Access Leads Executive Control
          </h1>
          <p className="text-xs text-zinc-400 mt-1">
            Real-time pipeline monitoring, telecalling activity, and Gemini AI insights.
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onNavigateToTab('telecaller')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-black bg-emerald-500 hover:bg-emerald-400 rounded-lg shadow transition"
          >
            <PhoneCall className="w-3.5 h-3.5" /> Start Telecalling Queue
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl shadow-sm space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Total Leads</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{totalLeads}</div>
          <p className="text-[11px] text-emerald-400 flex items-center gap-0.5">
            <ArrowUpRight className="w-3 h-3" /> Active directory
          </p>
        </div>

        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl shadow-sm space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Pipeline Value</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">
            ${totalPipelineValue.toLocaleString()}
          </div>
          <p className="text-[11px] text-zinc-400">Weighted forecast</p>
        </div>

        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl shadow-sm space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Conversion Rate</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{conversionRate}%</div>
          <p className="text-[11px] text-emerald-400">
            ${wonValue.toLocaleString()} won revenue
          </p>
        </div>

        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl shadow-sm space-y-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Hot AI Leads</span>
            <Flame className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{hotLeads.length}</div>
          <p className="text-[11px] text-amber-400 font-medium">Score &ge; 80 / Hot Intent</p>
        </div>

        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl shadow-sm space-y-1 col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-zinc-400 text-xs">
            <span>Calls Logged Today</span>
            <PhoneCall className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{callsToday}</div>
          <p className="text-[11px] text-cyan-400">Telecaller activity</p>
        </div>
      </div>

      {/* AI Intelligence Spotlight */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-semibold text-zinc-100">
              Gemini AI Pipeline Intelligence Summary
            </h2>
          </div>
          <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-medium border border-emerald-500/20">
            Automated Insights
          </span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-zinc-300">
          <div className="bg-[#09090b] p-3 rounded-xl border border-[#27272a] space-y-1">
            <span className="text-amber-400 font-semibold flex items-center gap-1">
              <Flame className="w-3.5 h-3.5" /> High Priority Deal Alert
            </span>
            <p className="text-zinc-400 leading-normal">
              <strong>Marcus Sterling (Apex Financial)</strong> has an AI intent score of 92 with $75k budget. Needs follow-up before EOD.
            </p>
          </div>
          <div className="bg-[#09090b] p-3 rounded-xl border border-[#27272a] space-y-1">
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" /> High-Converting Channel
            </span>
            <p className="text-zinc-400 leading-normal">
              <strong>Website & Inbound Calls</strong> yield a 38% conversion rate compared to 15% on cold outreach.
            </p>
          </div>
          <div className="bg-[#09090b] p-3 rounded-xl border border-[#27272a] space-y-1">
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" /> Telecaller Action Needed
            </span>
            <p className="text-zinc-400 leading-normal">
              4 inbound leads from Vanguard Logistics & BioMed Innovations await demo scheduling.
            </p>
          </div>
        </div>
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pipeline Stage Distribution */}
        <div className="lg:col-span-2 bg-[#18181b] border border-[#27272a] p-5 rounded-2xl shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
              Pipeline Stage Breakdown
            </h3>
            <button
              onClick={() => onNavigateToTab('kanban')}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium"
            >
              Open Kanban Board &rarr;
            </button>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stageChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fafafa',
                  }}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {stageChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={STAGE_COLORS[entry.key] || '#10b981'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lead Source Breakdown */}
        <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-zinc-100">Lead Sources</h3>
          <div className="h-52 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sourceChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={75}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {sourceChartData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={SOURCE_COLORS[index % SOURCE_COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fafafa',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {sourceChartData.map((src, idx) => (
              <div key={src.name} className="flex items-center space-x-2">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: SOURCE_COLORS[idx % SOURCE_COLORS.length] }}
                />
                <span className="text-zinc-300 truncate">{src.name}</span>
                <span className="text-zinc-500 font-mono">({src.value})</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row: Hot Leads Table & Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hot Leads Quick Action List */}
        <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400" /> Hot High-Value Prospects
            </h3>
            <button
              onClick={() => onNavigateToTab('leads')}
              className="text-xs text-emerald-400 hover:text-emerald-300"
            >
              View All Leads &rarr;
            </button>
          </div>

          <div className="space-y-2.5">
            {hotLeads.slice(0, 4).map((lead) => (
              <div
                key={lead.id}
                onClick={() => onSelectLead(lead)}
                className="p-3 bg-[#09090b] hover:bg-zinc-800/60 border border-[#27272a] rounded-xl transition cursor-pointer flex items-center justify-between"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-zinc-200 text-xs">{lead.name}</span>
                    <span className="px-2 py-0.5 text-[10px] bg-amber-500/10 text-amber-300 font-bold rounded-full border border-amber-500/20">
                      Score {lead.aiScore || 85}
                    </span>
                  </div>
                  <div className="text-[11px] text-zinc-400 flex items-center gap-2">
                    <span className="flex items-center gap-1">
                      <Building className="w-3 h-3 text-zinc-500" /> {lead.company}
                    </span>
                    <span>•</span>
                    <span className="text-emerald-400 font-medium">${lead.value.toLocaleString()}</span>
                  </div>
                </div>
                <div className="text-right text-[11px] text-zinc-400">
                  <span className="capitalize px-2 py-0.5 rounded bg-[#27272a] text-zinc-300">
                    {lead.stage.replace('_', ' ')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activities Feed */}
        <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl shadow-sm space-y-4">
          <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" /> Recent Telecaller Activity
          </h3>

          <div className="space-y-3">
            {activities.slice(0, 5).map((act) => {
              const matchedLead = leads.find((l) => l.id === act.leadId);
              return (
                <div
                  key={act.id}
                  className="flex items-start space-x-3 text-xs border-b border-[#27272a] pb-2.5 last:border-none"
                >
                  <div className="p-2 rounded-lg bg-[#09090b] border border-[#27272a] text-zinc-300 mt-0.5">
                    <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="flex-1 space-y-0.5">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-zinc-200">{act.title}</span>
                      <span className="text-[10px] text-zinc-500">
                        {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-zinc-400 text-[11px]">{act.description}</p>
                    <div className="flex items-center space-x-2 text-[10px] text-zinc-500">
                      <span>By: {act.performedBy}</span>
                      {matchedLead && (
                        <>
                          <span>•</span>
                          <span
                            onClick={() => onSelectLead(matchedLead)}
                            className="text-emerald-400 hover:underline cursor-pointer"
                          >
                            {matchedLead.name} ({matchedLead.company})
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
