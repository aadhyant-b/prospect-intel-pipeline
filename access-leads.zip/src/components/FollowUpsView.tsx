import React, { useState } from 'react';
import {
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  PhoneCall,
  Mail,
  Send,
  Sparkles,
  UserCheck,
  ChevronRight,
  Filter,
  Plus,
  ArrowRight,
  CalendarDays,
  Layers,
  Building2,
} from 'lucide-react';
import { Lead, Activity, Task, Meeting, CadenceRule } from '../types';

interface FollowUpsViewProps {
  leads: Lead[];
  tasks: Task[];
  meetings: Meeting[];
  cadenceRules: CadenceRule[];
  onOpenLeadDetail: (lead: Lead) => void;
  onLogCall: (lead: Lead) => void;
  onAdvanceCadence: (leadId: string) => void;
  onSnoozeTask: (taskId: string, days: number) => void;
  onCompleteTask: (taskId: string) => void;
}

export const FollowUpsView: React.FC<FollowUpsViewProps> = ({
  leads,
  tasks,
  meetings,
  cadenceRules,
  onOpenLeadDetail,
  onLogCall,
  onAdvanceCadence,
  onSnoozeTask,
  onCompleteTask,
}) => {
  const [activeTab, setActiveTab] = useState<'reminders' | 'cadence_engine' | 'meetings'>('reminders');
  const [timeFilter, setTimeFilter] = useState<'all' | 'due_today' | 'overdue' | 'upcoming'>('due_today');

  const todayStr = new Date().toISOString().split('T')[0];

  // Map tasks to leads
  const leadMap = new Map<string, Lead>(leads.map((l) => [l.id, l]));

  // Filter tasks
  const pendingTasks = tasks.filter((t) => !t.completed);

  const filteredTasks = pendingTasks.filter((task) => {
    if (timeFilter === 'due_today') return task.dueDate === todayStr;
    if (timeFilter === 'overdue') return task.dueDate < todayStr;
    if (timeFilter === 'upcoming') return task.dueDate > todayStr;
    return true;
  });

  const overdueCount = pendingTasks.filter((t) => t.dueDate < todayStr).length;
  const todayCount = pendingTasks.filter((t) => t.dueDate === todayStr).length;
  const upcomingCount = pendingTasks.filter((t) => t.dueDate > todayStr).length;

  return (
    <div className="space-y-6">
      {/* Top Banner & Stats */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <Clock className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-zinc-100">
              Follow-Ups, Reminders & Cadence Management
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Automated multi-channel sales cadence tracking, daily follow-up queue, and scheduled decision meetings.
          </p>
        </div>

        {/* Quick Task Counters */}
        <div className="flex items-center space-x-2 text-xs">
          <button
            onClick={() => {
              setActiveTab('reminders');
              setTimeFilter('due_today');
            }}
            className={`px-3 py-2 rounded-xl border flex items-center gap-1.5 transition ${
              timeFilter === 'due_today' && activeTab === 'reminders'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 font-bold'
                : 'bg-[#09090b] border-[#27272a] text-zinc-300'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Due Today ({todayCount})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('reminders');
              setTimeFilter('overdue');
            }}
            className={`px-3 py-2 rounded-xl border flex items-center gap-1.5 transition ${
              timeFilter === 'overdue' && activeTab === 'reminders'
                ? 'bg-rose-500/10 border-rose-500/30 text-rose-400 font-bold'
                : 'bg-[#09090b] border-[#27272a] text-zinc-300'
            }`}
          >
            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
            <span>Overdue ({overdueCount})</span>
          </button>
        </div>
      </div>

      {/* Main Tabs */}
      <div className="flex border-b border-[#27272a] text-xs font-semibold space-x-4">
        <button
          onClick={() => setActiveTab('reminders')}
          className={`pb-3 border-b-2 flex items-center gap-2 transition ${
            activeTab === 'reminders'
              ? 'border-emerald-400 text-emerald-400 font-bold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Clock className="w-4 h-4 text-emerald-400" /> Follow-Up Queue ({filteredTasks.length})
        </button>
        <button
          onClick={() => setActiveTab('cadence_engine')}
          className={`pb-3 border-b-2 flex items-center gap-2 transition ${
            activeTab === 'cadence_engine'
              ? 'border-emerald-400 text-emerald-400 font-bold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Layers className="w-4 h-4 text-emerald-400" /> Automated Cadence Engine
        </button>
        <button
          onClick={() => setActiveTab('meetings')}
          className={`pb-3 border-b-2 flex items-center gap-2 transition ${
            activeTab === 'meetings'
              ? 'border-emerald-400 text-emerald-400 font-bold'
              : 'border-transparent text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <CalendarDays className="w-4 h-4 text-emerald-400" /> Scheduled Meetings ({meetings.length})
        </button>
      </div>

      {/* TAB 1: FOLLOW-UP QUEUE */}
      {activeTab === 'reminders' && (
        <div className="space-y-4">
          {/* Sub-filters */}
          <div className="flex items-center space-x-2 text-xs bg-[#18181b] p-2 rounded-xl border border-[#27272a]">
            <span className="text-zinc-500 font-medium px-2">Filter By:</span>
            {(['due_today', 'overdue', 'upcoming', 'all'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setTimeFilter(filter)}
                className={`px-3 py-1 rounded-lg capitalize transition font-medium ${
                  timeFilter === filter
                    ? 'bg-emerald-500 text-black font-semibold shadow'
                    : 'text-zinc-400 hover:text-zinc-100 hover:bg-[#09090b]'
                }`}
              >
                {filter.replace('_', ' ')}
              </button>
            ))}
          </div>

          {/* Task Cards List */}
          {filteredTasks.length === 0 ? (
            <div className="bg-[#18181b] border border-[#27272a] rounded-2xl p-8 text-center text-zinc-400 text-xs">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
              <p className="font-semibold text-zinc-200">All caught up!</p>
              <p className="mt-1 text-zinc-500">No pending follow-up reminders found for this filter.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3">
              {filteredTasks.map((task) => {
                const lead = leadMap.get(task.leadId);
                const isOverdue = task.dueDate < todayStr;
                const isToday = task.dueDate === todayStr;

                return (
                  <div
                    key={task.id}
                    className="bg-[#18181b] border border-[#27272a] hover:border-emerald-500/50 p-4 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 transition"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2 text-xs">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            isOverdue
                              ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                              : isToday
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          }`}
                        >
                          {isOverdue ? 'Overdue' : isToday ? 'Due Today' : `Due ${task.dueDate}`}
                        </span>

                        <span className="text-zinc-400">•</span>
                        <span className="font-semibold text-zinc-200">{task.title}</span>
                      </div>

                      {lead ? (
                        <div className="flex items-center space-x-3 text-xs text-zinc-400">
                          <button
                            onClick={() => onOpenLeadDetail(lead)}
                            className="text-emerald-400 hover:underline font-bold"
                          >
                            {lead.name}
                          </button>
                          <span>at {lead.company}</span>
                          <span>• Step {lead.cadenceStep || 1} of 5</span>
                        </div>
                      ) : (
                        <p className="text-xs text-zinc-500">Assigned: {task.assignedTo}</p>
                      )}
                    </div>

                    {/* Quick Action Buttons */}
                    <div className="flex items-center flex-wrap gap-2 text-xs">
                      {lead && (
                        <>
                          <button
                            onClick={() => onLogCall(lead)}
                            className="px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg font-semibold flex items-center gap-1"
                          >
                            <PhoneCall className="w-3.5 h-3.5" /> Call Now
                          </button>

                          <button
                            onClick={() => onOpenLeadDetail(lead)}
                            className="px-3 py-1.5 bg-[#09090b] hover:bg-[#27272a] text-zinc-200 border border-[#27272a] rounded-lg font-semibold flex items-center gap-1"
                          >
                            <Mail className="w-3.5 h-3.5 text-emerald-400" /> Draft Email
                          </button>
                        </>
                      )}

                      <button
                        onClick={() => onSnoozeTask(task.id, 2)}
                        className="px-2.5 py-1.5 bg-[#09090b] hover:bg-[#27272a] text-zinc-400 hover:text-zinc-200 border border-[#27272a] rounded-lg font-medium"
                        title="Snooze reminder by 2 days"
                      >
                        +2 Days
                      </button>

                      <button
                        onClick={() => onCompleteTask(task.id)}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-lg flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Done
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: AUTOMATED CADENCE ENGINE */}
      {activeTab === 'cadence_engine' && (
        <div className="bg-[#18181b] border border-[#27272a] p-6 rounded-2xl space-y-6">
          <div>
            <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400" /> Standard Pursuit Cadence Schedule
            </h3>
            <p className="text-xs text-zinc-400 mt-0.5">
              Every newly imported Salesforce or self-prospected lead progresses through this 5-step automated multi-touch sequence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {cadenceRules.map((rule) => (
              <div
                key={rule.stepNumber}
                className="bg-[#09090b] border border-[#27272a] p-4 rounded-xl flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold">
                      Step {rule.stepNumber}
                    </span>
                    <span className="text-zinc-500 text-[11px]">Day +{rule.dayOffset}</span>
                  </div>
                  <h4 className="font-bold text-zinc-200 text-xs">{rule.title}</h4>
                  <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed">{rule.description}</p>
                </div>

                <div className="pt-2 border-t border-[#27272a] text-[10px] text-emerald-400 font-medium">
                  Style: {rule.recommendedStyle}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: SCHEDULED MEETINGS */}
      {activeTab === 'meetings' && (
        <div className="bg-[#18181b] border border-[#27272a] p-6 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
                <CalendarDays className="w-4 h-4 text-emerald-400" /> Decision Meetings & Demos
              </h3>
              <p className="text-xs text-zinc-400">
                Confirmed calendar appointments with qualified decision makers.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {meetings.map((m) => (
              <div key={m.id} className="bg-[#09090b] border border-[#27272a] p-4 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-zinc-100 text-sm">{m.title}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 font-bold border border-emerald-500/20">
                    {m.status}
                  </span>
                </div>

                <div className="flex items-center space-x-2 text-zinc-400">
                  <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="font-semibold text-zinc-200">{m.leadName}</span>
                  <span>({m.company})</span>
                </div>

                <div className="flex items-center space-x-4 text-zinc-400 pt-1">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-zinc-500" /> {m.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-zinc-500" /> {m.time}
                  </span>
                </div>

                <p className="text-zinc-400 text-[11px] bg-[#18181b] p-2 rounded-lg border border-[#27272a]">
                  <strong>Agenda:</strong> {m.notes}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
