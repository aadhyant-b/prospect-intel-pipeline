import React, { useState } from 'react';
import { X, PhoneCall, CheckCircle } from 'lucide-react';
import { Lead, CallOutcome } from '../types';

interface CallLogModalProps {
  lead: Lead | null;
  onClose: () => void;
  onLogCall: (
    leadId: string,
    outcome: CallOutcome,
    notes: string,
    durationSeconds: number,
    nextFollowUpDate?: string
  ) => void;
}

export const CallLogModal: React.FC<CallLogModalProps> = ({ lead, onClose, onLogCall }) => {
  if (!lead) return null;

  const [outcome, setOutcome] = useState<CallOutcome>('Connected - Interested');
  const [durationMinutes, setDurationMinutes] = useState(5);
  const [notes, setNotes] = useState('');
  const [nextDate, setNextDate] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogCall(lead.id, outcome, notes, durationMinutes * 60, nextDate || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#18181b] border border-[#27272a] w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden text-zinc-100 my-auto">
        <div className="bg-[#09090b] p-4 border-b border-[#27272a] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="p-1 rounded bg-emerald-500/10 text-emerald-400">
              <PhoneCall className="w-4 h-4" />
            </span>
            <h2 className="text-sm font-bold text-zinc-100">
              Log Call Activity for {lead.name}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div>
            <label className="text-zinc-300 font-semibold block mb-1">Call Outcome</label>
            <select
              value={outcome}
              onChange={(e) => setOutcome(e.target.value as CallOutcome)}
              className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2.5 focus:outline-none"
            >
              <option value="Connected - Interested">Connected - Interested</option>
              <option value="Connected - Callback Requested">Connected - Callback Requested</option>
              <option value="Connected - Not Interested">Connected - Not Interested</option>
              <option value="Left Voicemail">Left Voicemail</option>
              <option value="No Answer / Busy">No Answer / Busy</option>
              <option value="Wrong Number">Wrong Number</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Duration (Minutes)</label>
              <input
                type="number"
                min="1"
                max="120"
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-zinc-300 font-semibold block mb-1">Callback Date (Optional)</label>
              <input
                type="date"
                value={nextDate}
                onChange={(e) => setNextDate(e.target.value)}
                className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-zinc-300 font-semibold block mb-1">Call Notes & Key Discussion</label>
            <textarea
              rows={4}
              required
              placeholder="e.g. Discussed proposal terms. Prospect confirmed budget authorization and requested follow-up demo."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#09090b] text-zinc-100 border border-[#27272a] rounded-lg p-2.5 focus:outline-none"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-2 border-t border-[#27272a]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-[#09090b] hover:bg-zinc-800 text-zinc-300 border border-[#27272a] rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-semibold rounded-lg shadow-sm flex items-center gap-1.5"
            >
              <CheckCircle className="w-4 h-4 text-black" /> Save Call Log
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
