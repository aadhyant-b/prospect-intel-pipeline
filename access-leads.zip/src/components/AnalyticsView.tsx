import React from 'react';
import {
  TrendingUp,
  Award,
  Users,
  DollarSign,
  PhoneCall,
  PieChart as PieIcon,
  BarChart2,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { Lead, Activity, TeamMember } from '../types';

interface AnalyticsViewProps {
  leads: Lead[];
  activities: Activity[];
  team: TeamMember[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  leads,
  activities,
  team,
}) => {
  const totalLeads = leads.length;
  const wonLeads = leads.filter((l) => l.stage === 'won');
  const totalWonRevenue = wonLeads.reduce((sum, l) => sum + (l.value || 0), 0);
  const totalCalls = activities.filter((a) => a.type === 'call').length;

  // Funnel Data
  const funnel = [
    { stage: 'Total Inbound/Sourced', count: leads.length, pct: 100 },
    {
      stage: 'Contacted',
      count: leads.filter((l) => l.stage !== 'new').length,
      pct: leads.length > 0 ? Math.round((leads.filter((l) => l.stage !== 'new').length / leads.length) * 100) : 0,
    },
    {
      stage: 'Qualifying / Proposal',
      count: leads.filter((l) => ['qualifying', 'proposal_sent', 'negotiation', 'won'].includes(l.stage)).length,
      pct: leads.length > 0 ? Math.round((leads.filter((l) => ['qualifying', 'proposal_sent', 'negotiation', 'won'].includes(l.stage)).length / leads.length) * 100) : 0,
    },
    {
      stage: 'Closed Won',
      count: wonLeads.length,
      pct: leads.length > 0 ? Math.round((wonLeads.length / leads.length) * 100) : 0,
    },
  ];

  // Lead Source Efficiency
  const sourceStats: Record<string, { total: number; won: number; revenue: number }> = {};
  leads.forEach((l) => {
    if (!sourceStats[l.source]) {
      sourceStats[l.source] = { total: 0, won: 0, revenue: 0 };
    }
    sourceStats[l.source].total += 1;
    if (l.stage === 'won') {
      sourceStats[l.source].won += 1;
      sourceStats[l.source].revenue += l.value || 0;
    }
  });

  const sourceChartData = Object.keys(sourceStats).map((k) => ({
    source: k,
    revenue: sourceStats[k].revenue,
    total: sourceStats[k].total,
    won: sourceStats[k].won,
    winRate: sourceStats[k].total > 0 ? Math.round((sourceStats[k].won / sourceStats[k].total) * 100) : 0,
  }));

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-zinc-100 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" /> Sales & Telecaller Performance Analytics
        </h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          In-depth revenue metrics, conversion funnels, and team telecalling leaderboards.
        </p>
      </div>

      {/* Top Overview Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl space-y-1">
          <span className="text-zinc-400 text-xs">Closed Won Revenue</span>
          <div className="text-2xl font-bold text-emerald-400">
            ${totalWonRevenue.toLocaleString()}
          </div>
          <span className="text-[11px] text-zinc-500">{wonLeads.length} closed deals</span>
        </div>

        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl space-y-1">
          <span className="text-zinc-400 text-xs">Lead Win Rate</span>
          <div className="text-2xl font-bold text-zinc-100">
            {totalLeads > 0 ? Math.round((wonLeads.length / totalLeads) * 100) : 0}%
          </div>
          <span className="text-[11px] text-emerald-400">Outperforms industry benchmark</span>
        </div>

        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl space-y-1">
          <span className="text-zinc-400 text-xs">Total Calls Logged</span>
          <div className="text-2xl font-bold text-cyan-400">{totalCalls}</div>
          <span className="text-[11px] text-zinc-500">Recorded telecaller activity</span>
        </div>

        <div className="bg-[#18181b] border border-[#27272a] p-4 rounded-xl space-y-1">
          <span className="text-zinc-400 text-xs">Avg. Deal Size</span>
          <div className="text-2xl font-bold text-zinc-100">
            ${wonLeads.length > 0 ? Math.round(totalWonRevenue / wonLeads.length).toLocaleString() : '0'}
          </div>
          <span className="text-[11px] text-zinc-500">Per closed contract</span>
        </div>
      </div>

      {/* Funnel & Source Revenue */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Conversion Funnel */}
        <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-4">
          <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-emerald-400" /> Lead Conversion Funnel
          </h3>

          <div className="space-y-3">
            {funnel.map((item, idx) => (
              <div key={item.stage} className="space-y-1">
                <div className="flex justify-between text-xs text-zinc-300 font-medium">
                  <span>{item.stage}</span>
                  <span>
                    {item.count} leads ({item.pct}%)
                  </span>
                </div>
                <div className="w-full bg-[#09090b] h-3 rounded-full overflow-hidden border border-[#27272a]">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500"
                    style={{ width: `${item.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue by Source Chart */}
        <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-4">
          <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-400" /> Won Revenue by Lead Channel
          </h3>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sourceChartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <XAxis dataKey="source" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#09090b',
                    borderColor: '#27272a',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fafafa',
                  }}
                  formatter={(value: any) => `$${Number(value).toLocaleString()}`}
                />
                <Bar dataKey="revenue" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Telecaller Leaderboard */}
      <div className="bg-[#18181b] border border-[#27272a] p-5 rounded-2xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" /> Telecaller Team Leaderboard
          </h3>
          <span className="text-xs text-zinc-400">Monthly Ranking</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#27272a] text-zinc-400 font-semibold">
                <th className="pb-2">Sales Rep / Telecaller</th>
                <th className="pb-2">Role</th>
                <th className="pb-2">Assigned Leads</th>
                <th className="pb-2">Calls Today</th>
                <th className="pb-2">Deals Closed</th>
                <th className="pb-2">Revenue Won</th>
                <th className="pb-2">Win Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#27272a]">
              {team.map((member) => (
                <tr key={member.id} className="hover:bg-zinc-800/40 transition">
                  <td className="py-3 flex items-center space-x-2">
                    <img
                      src={member.avatar}
                      alt={member.name}
                      className="w-7 h-7 rounded-full object-cover border border-[#27272a]"
                    />
                    <span className="font-semibold text-zinc-200">{member.name}</span>
                  </td>
                  <td className="py-3 capitalize text-zinc-400">{member.role}</td>
                  <td className="py-3 font-semibold text-zinc-300">{member.assignedLeadsCount}</td>
                  <td className="py-3 font-bold text-cyan-400">{member.callsToday}</td>
                  <td className="py-3 font-bold text-emerald-400">{member.dealsClosed}</td>
                  <td className="py-3 font-bold text-zinc-200">
                    ${member.revenueClosed.toLocaleString()}
                  </td>
                  <td className="py-3 text-emerald-400 font-semibold">
                    {member.conversionRate}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
